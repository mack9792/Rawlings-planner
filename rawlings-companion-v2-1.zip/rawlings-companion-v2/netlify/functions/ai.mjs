import { createAiHandler } from '../lib/ai.js';
import { defaultDeps } from '../lib/http.js';

export default async (req) => createAiHandler(defaultDeps())(req);
export const config = { path: '/api/ai' };
