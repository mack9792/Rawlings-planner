import { createTranscribeHandler } from '../lib/transcribe.js';
import { defaultDeps } from '../lib/http.js';

export default async (req) => createTranscribeHandler(defaultDeps())(req);
export const config = { path: '/api/transcribe' };
