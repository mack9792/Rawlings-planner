import { createGoogleHandler } from '../lib/google.js';
import { defaultDeps } from '../lib/http.js';

export default async (req) => createGoogleHandler(defaultDeps())(req);
export const config = { path: '/api/google/*' };
