# Deployment-readiness and security audit (final pass, 23 Oct 2026)

Legend: PASS = verified by a real test. FAIL = problem found. NOT TESTED = could not be tested (reason given).
No secret values appear in this file or anywhere in the project.

| # | Section | Result |
|---|---|---|
| 1 | Inspect project/ZIP, secret scan | **PASS** |
| 2 | Real Supabase connection | **PARTIAL.** Read-only inspection PASS. Sign-up/login/logout/recovery and cross-user isolation on the real project: **NOT TESTED** |
| 3 | Real AI and voice | **NOT TESTED**. No Anthropic or Groq key exists in this environment |
| 4 | Google integrations | **NOT TESTED**. No Google OAuth client is configured for this app |
| 5 | Deployment readiness | Build/config/unit/browser/SQL: **PASS**. Live Netlify deployment and end-to-end: **NOT TESTED** |
| 6 | Fixes | 2 documentation fixes this pass (plus 2 earlier). No migration, no production change |

## Tests run and actual results
- `npm test`: 62 passed, 0 failed (1 SQL test skipped without a database).
- Same suite with a scratch **PostgreSQL 16** loaded with `tests/db/supabase_stub.sql`: 63/63 passed, including "schema applies twice" and the cross-user isolation script. SIMULATED Supabase (stand-in for auth/storage tables).
- `node scripts/build.mjs` and `verify:dist`: build succeeds; no secret names or values in `dist/`; all imports resolve.
- Browser smoke test (Chromium, 390px mobile): 27/27 passed. SIMULATED backend (request interception).
- Secret scan (key patterns, credential assignments, key/env files in the ZIP): clean. Only deliberately fake strings inside tests; `.env.example` has names only. **No credential needs rotating.**

## Real vs simulated
- **Real (read-only):** Supabase project metadata, tables, RLS flags, policies, buckets, grants, migration list, security advisors, auth-user count.
- **Simulated:** sign-in flows, AI, transcription, Google flows, browser run, RLS isolation (local Postgres).
- **Not touched:** no user was created, no row written, no email sent, no calendar/sheet/Gmail access.

## Connected Supabase project (read-only findings)
- One project, "Lumiere-hub1's Project", ACTIVE_HEALTHY. It is **not confirmed to be Rawlings' own**; it appears to belong to another workspace. Do not deploy this app into it.
- Contains the old 4-table layout only (tasks, projects, meetings, notes): empty, RLS on, 0 auth users, 0 storage buckets, no migrations, 0 security advisories.
- **The v2 schema is not applied.** `projects` lacks `next_steps`; there is no `auth.uid()` default on `user_id`; incidents, decisions, ai_history, voice_notes, uploaded_files, google_tokens and the private bucket are absent. `schema.sql` would skip the 4 existing tables (`create table if not exists`) and leave the app broken. Use a fresh Rawlings-owned project.
- Old tables leave the `anon` role with TRUNCATE/REFERENCES/TRIGGER grants (Supabase default). v2 `schema.sql` revokes all anon access on its tables.

## Code review findings
- Auth: every server function verifies the bearer token with Supabase Auth. The service-role key is used only server-side (Google token table). Build refuses a service-role key in the public slot. PASS.
- Google: refresh tokens AES-256-GCM encrypted; OAuth state HMAC-signed with 10-minute expiry; every write needs explicit confirmation; spreadsheet text cannot become a formula. PASS (unit-tested only).
- **Medium: cost exposure.** If `ALLOWED_EMAILS` is empty and sign-ups are open, anyone who registers can spend your AI/voice credits. Set `ALLOWED_EMAILS` and disable public sign-ups.
- **Medium: over-broad Google scopes.** `spreadsheets` grants access to all of your sheets; the app only creates new ones, so `drive.file` would be enough. `gmail.compose` is Google's narrowest scope for drafts but also permits sending (code never sends). Narrowing Sheets is a consent-screen change, so it was **not made without your approval**.
- **Unverified: function timeouts.** AI/transcribe calls allow up to 25 s. Check your Netlify plan's function timeout; if it is shorter, long requests will fail with a platform error instead of the app's friendly message.

## Changes made (all safe, no behaviour change)
- `netlify/lib/http.js`: optional `ALLOWED_EMAILS` allow-list (default off).
- `netlify/lib/google.js`: apostrophes in sheet names escaped; scope comment corrected.
- `README.md`: note status corrected (the note IS included); Gmail wording corrected.
- `.env.example`, tests updated earlier. `content/bibish-note.txt` untouched (SHA-256 fb0f75c6...fac2d2, locked by tests).

## What you must do to finish (nothing here was done for you)
1. Create a Supabase project you own; run `supabase/schema.sql`, then `supabase/rls_isolation_check.sql` (must end "Success: all isolation checks passed").
2. Set Netlify variables per `.env.example`; set `ALLOWED_EMAILS`; turn off public sign-ups after creating your account.
3. Add `ANTHROPIC_API_KEY` and `GROQ_API_KEY`; then test one AI command and one voice note.
4. Optional Google setup per README step 4; add the redirect URI `https://YOUR-SITE/api/google/callback`.
5. Re-run this audit against the live site; sections 2 to 5 stay unproven until then.
