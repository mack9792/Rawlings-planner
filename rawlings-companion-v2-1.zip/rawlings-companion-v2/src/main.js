// App shell: session handling, hash router, navigation. Views live in ./views.
import { h, clear } from './lib/dom.js';
import { supabase } from './lib/supabase.js';
import { parseRecoveryHash } from './lib/recovery.js';
import { renderAuth } from './views/auth.js';
import { render as dashboard } from './views/dashboard.js';
import { render as ai } from './views/ai.js';
import { render as voice } from './views/voice.js';
import { render as files } from './views/files.js';
import { render as google } from './views/google.js';
import { render as help } from './views/help.js';
import { render as note, NOTE_TITLE } from './views/note.js';
import { ENTITIES, entityPanel } from './views/entities.js';

const panelView = (...keys) => (ctx) => h('div', {}, keys.map((k) => entityPanel(ctx, ENTITIES[k])));

export const ROUTES = [
  ['dashboard', 'Dashboard', dashboard],
  ['projects', 'Projects', panelView('projects')],
  ['incidents', 'Incidents', panelView('incidents')],
  ['ai', 'AI', ai],
  ['voice', 'Voice', voice],
  ['files', 'Files', files],
  ['records', 'Records', panelView('tasks', 'meetings', 'decisions', 'notes')],
  ['google', 'Google', google],
  ['help', 'Help', help],
];
const NOTE_ROUTE = 'note';

const app = document.getElementById('app');
let leaveFns = [];
const leave = () => { leaveFns.forEach((f) => { try { f(); } catch { /* ignore */ } }); leaveFns = []; };

function routeName() { return (location.hash.replace(/^#\/?/, '').split('?')[0]) || 'dashboard'; }

function showApp() {
  clear(app);
  const content = h('main', { class: 'page', id: 'content', tabindex: '-1' });
  const nav = h('nav', { class: 'nav', 'aria-label': 'Main' });
  app.append(
    h('header', { class: 'topbar' }, h('span', { class: 'brand' }, 'Rawlings ', h('em', {}, 'Executive Companion')),
      h('a', { class: `note-link ${routeName() === NOTE_ROUTE ? 'on' : ''}`, href: `#/${NOTE_ROUTE}` }, '❤️ A note for you')),
    nav, content);

  const ctx = { db: supabase, user: supabase.user || {}, onLeave: (fn) => leaveFns.push(fn), signOut: async () => { leave(); await supabase.signOut(); boot(); } };

  function draw() {
    leave();
    const name = routeName();
    const found = ROUTES.find(([k]) => k === name);
    clear(nav).append(...ROUTES.map(([k, label]) => h('a', { href: `#/${k}`, class: k === name ? 'on' : '', 'aria-current': k === name ? 'page' : null }, label)));
    document.querySelector('.note-link')?.classList.toggle('on', name === NOTE_ROUTE);
    document.title = `${name === NOTE_ROUTE ? NOTE_TITLE : (found ? found[1] : 'Dashboard')} · Rawlings Executive Companion`;
    clear(content);
    document.body.classList.toggle('note-mode', name === NOTE_ROUTE);
    try {
      content.append(name === NOTE_ROUTE ? note() : (found || ROUTES[0])[2](ctx));
    } catch (e) { content.append(h('p', { class: 'error' }, 'Something went wrong showing this page. Please refresh.')); console.error(e); }
    window.scrollTo(0, 0);
  }
  window.onhashchange = draw;
  supabase.onChange((s) => { if (!s) boot(); }); // session ended (expired or signed out elsewhere)
  draw();
}

function boot() {
  leave();
  window.onhashchange = null;
  document.body.classList.remove('note-mode');
  const recovery = parseRecoveryHash(location.hash);
  if (!recovery && supabase.session) return showApp();
  clear(app).append(renderAuth(supabase, { recoveryToken: recovery && recovery.token, onSignedIn: () => { location.hash = '#/dashboard'; showApp(); } }));
}

boot();
