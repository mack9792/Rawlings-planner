// Development stub. `npm run build` writes the real dist/config.js from the
// SUPABASE_URL and SUPABASE_ANON_KEY environment variables. Only these two
// PUBLIC values are ever placed here. Never put a secret key in this file.
export const CONFIG = { SUPABASE_URL: '', SUPABASE_ANON_KEY: '' };
