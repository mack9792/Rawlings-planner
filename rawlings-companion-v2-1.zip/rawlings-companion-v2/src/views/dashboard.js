// IT Leadership Dashboard: priorities, deadlines, meetings, projects, decisions, follow-ups.
import { h, clear, fmtDate, todayStr } from '../lib/dom.js';
import { ENTITIES, entityPanel } from './entities.js';
import { showError } from './aiResult.js';

const greeting = () => { const hr = new Date().getHours(); return hr < 12 ? 'Good morning' : hr < 18 ? 'Good afternoon' : 'Good evening'; };

export function render(ctx) {
  const body = h('div', {});
  const quick = h('div', {});

  async function load() {
    clear(body).append(h('p', { class: 'muted' }, 'Loading your dashboard…'));
    const today = todayStr();
    const in7 = new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10);
    try {
      const [tasks, projects, incidents, meetings, decisions] = await Promise.all([
        ctx.db.select('tasks', 'select=*&done=eq.false&order=due_date.asc.nullslast&limit=200'),
        ctx.db.select('projects', 'select=*&status=neq.Done&order=created_at.desc&limit=50'),
        ctx.db.select('incidents', 'select=*&status=neq.Resolved&order=created_at.desc&limit=50'),
        ctx.db.select('meetings', `select=*&meeting_date=gte.${today}&meeting_date=lte.${in7}&order=meeting_date.asc,meeting_time.asc.nullslast&limit=20`),
        ctx.db.select('decisions', 'select=*&status=in.(Pending,Revisit)&order=decide_by.asc.nullslast&limit=20'),
      ]);
      const overdue = tasks.filter((t) => t.due_date && t.due_date < today);
      const priorities = tasks.filter((t) => ['High', 'Critical'].includes(t.priority) || (t.due_date && t.due_date <= today) ).slice(0, 8);
      const followUps = tasks.filter((t) => t.kind === 'follow_up').slice(0, 8);
      const blocked = projects.filter((p) => p.status === 'Blocked');
      const tile = (n, label, warn) => h('div', { class: `tile ${warn && n ? 'warn' : ''}` }, h('b', {}, String(n)), h('span', {}, label));

      const list = (title, rows, empty, line) => h('section', { class: 'panel' }, h('h3', {}, title), rows.length ? h('ul', { class: 'plain' }, rows.map(line)) : h('p', { class: 'muted empty' }, empty));

      clear(body).append(
        h('div', { class: 'tiles' },
          tile(tasks.length, 'Open tasks'), tile(overdue.length, 'Overdue', true),
          tile(projects.length, 'Active projects'), tile(blocked.length, 'Blocked projects', true),
          tile(incidents.length, 'Open incidents', true), tile(decisions.length, 'Decisions pending')),
        h('div', { class: 'cols' },
          list('Priorities', priorities, 'Nothing urgent. Add a task below.', (t) => h('li', {}, h('strong', {}, t.title), ' ', h('span', { class: `chip ${t.priority === 'Critical' || t.priority === 'High' ? 'warn' : ''}` }, t.priority), t.due_date ? h('span', { class: 'chip' }, `${t.due_date < today ? 'overdue ' : 'due '}${fmtDate(t.due_date)}`) : null)),
          list('Meetings — next 7 days', meetings, 'No meetings in the next week.', (m) => h('li', {}, h('strong', {}, m.title), ' ', h('span', { class: 'chip' }, `${fmtDate(m.meeting_date)}${m.meeting_time ? ` ${m.meeting_time.slice(0, 5)}` : ''}`)))),
        h('div', { class: 'cols' },
          h('section', { class: 'panel' }, h('h3', {}, 'Projects'),
            projects.length ? h('ul', { class: 'plain' }, projects.slice(0, 8).map((p) => h('li', {}, h('strong', {}, p.title), ' ', h('span', { class: `chip ${p.status === 'Blocked' ? 'warn' : ''}` }, p.status),
              h('div', { class: 'bar', role: 'img', 'aria-label': `${p.progress}% complete` }, h('i', { style: `width:${p.progress}%` }))))) : h('p', { class: 'muted empty' }, 'No active projects. Add one under Projects.')),
          list('Follow-ups', followUps, 'No open follow-ups.', (t) => h('li', {}, h('strong', {}, t.title), t.due_date ? h('span', { class: 'chip' }, `due ${fmtDate(t.due_date)}`) : null))),
        list('Decisions to make', decisions, 'No pending decisions.', (d) => h('li', {}, h('strong', {}, d.title), ' ', h('span', { class: 'chip' }, d.status), d.decide_by ? h('span', { class: 'chip' }, `by ${fmtDate(d.decide_by)}`) : null)),
        ...(incidents.length ? [list('Open incidents', incidents.slice(0, 6), '', (i) => h('li', {}, h('strong', {}, i.title), ' ', h('span', { class: `chip ${['High', 'Critical'].includes(i.severity) ? 'warn' : ''}` }, i.severity), h('span', { class: 'chip' }, i.status)))] : []));
    } catch (e) { clear(body); showError(body, e.message); body.append(h('button', { class: 'btn small', type: 'button', onclick: load }, 'Retry')); }
  }

  clear(quick).append(entityPanel(ctx, { ...ENTITIES.tasks, plural: 'Quick add: task or follow-up' }, { filter: 'done=eq.false', limit: 5, onChange: load, compactForm: true }));
  load();
  return h('div', {}, h('h1', { class: 'page-title' }, greeting(), '.'), body, quick);
}
