// The personal message. Deliberately separate from the professional dashboard.
// The text lives in content/bibish-note.txt and is embedded at build time as /note.json.
import { h, clear } from '../lib/dom.js';

export const NOTE_TITLE = 'A Little Note from Your Bibish ❤️';
export const PLACEHOLDER_MARK = '@@PLACEHOLDER@@';

/** Pure: turn raw text into paragraphs, or report that the real message has not been added. */
export function parseNote(raw) {
  const text = String(raw ?? '').replace(/\r\n/g, '\n').trim();
  if (!text || text.includes(PLACEHOLDER_MARK)) return { ready: false, paragraphs: [] };
  const paragraphs = text.split(/\n{2,}/).map((p) => p.trim()).filter(Boolean);
  // The message file begins with the title; the page already shows it as the heading, so don't repeat it.
  if (paragraphs[0] === NOTE_TITLE) paragraphs.shift();
  return { ready: paragraphs.length > 0, paragraphs };
}

export function render() {
  const body = h('div', { class: 'note-body' }, h('p', { class: 'muted' }, 'Loading…'));
  (async () => {
    try {
      const r = await fetch('/note.json', { cache: 'no-store' });
      if (!r.ok) throw new Error('missing');
      const { text } = await r.json();
      const n = parseNote(text);
      clear(body);
      if (!n.ready) body.append(h('p', { class: 'notice' }, 'The personal message has not been added to this build yet. The app owner needs to paste it into content/bibish-note.txt and redeploy.'));
      else n.paragraphs.forEach((p) => body.append(h('p', {}, ...p.split('\n').flatMap((line, i) => (i ? [h('br'), line] : [line])))));
    } catch { clear(body).append(h('p', { class: 'notice' }, 'The message could not be loaded. Please refresh the page.')); }
  })();
  return h('div', { class: 'note-page' }, h('article', { class: 'note-card' }, h('h1', {}, NOTE_TITLE), body));
}
