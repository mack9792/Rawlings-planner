// Help, usage instructions, and account settings (change password, sign out).
import { h, toast } from '../lib/dom.js';
import { validatePassword } from '../lib/validate.js';

const SECTIONS = [
  ['Getting started', ['Use the menu to move between Dashboard, Projects, Incidents, AI, Voice, Files, Records and Google.', 'Everything you enter is private to your account. Nobody else can see it.', 'Add your first task or project, and the Dashboard fills in automatically.']],
  ['AI Command Center', ['Choose a mode: Ask anything, Help with a document, or Extract action items.', 'Paste text for the document modes. Press Send and wait a few seconds.', 'Action items can be ticked and added straight to your tasks.', 'If the AI is not configured or the service is busy, you will see a clear message. It never makes up an answer.']],
  ['Voice notes', ['Press Start recording and allow the microphone when your browser asks.', 'Press Stop, then play it back. Discard removes it; Transcribe turns it into text.', 'Always read and correct the transcript before using it. Speech recognition can make mistakes.', 'Then ask the AI for a summary or action items, and Save note to keep it.']],
  ['Files', ['Supported: TXT, MD, CSV, JSON, PDF, PNG, JPG and WebP. Word and Excel files are not supported yet: save as PDF or copy the text.', 'Text files up to 200 KB; PDFs and images up to 3 MB.', 'Tick "keep a private copy" only if you want the file stored in your account.']],
  ['Google (optional)', ['Connect once; Google asks you to approve. You can disconnect any time.', 'You will always see a confirmation screen before an event, sheet or draft is created.', 'Email is only saved as a Gmail draft. This app never sends email for you.']],
  ['Privacy', ['Your data is stored in a database that you own, and each account can only read its own rows.', 'There is no tracking, advertising, or hidden administrator access.', 'AI text and voice recordings are sent to the AI and transcription providers only when you press the button for that.']],
];

export function render(ctx) {
  const pw = h('input', { type: 'password', autocomplete: 'new-password', minlength: 10, maxlength: 72 });
  const pw2 = h('input', { type: 'password', autocomplete: 'new-password', minlength: 10, maxlength: 72 });
  const form = h('form', { class: 'form', novalidate: true },
    h('label', { class: 'field' }, h('span', {}, 'New password (10+ characters)'), pw),
    h('label', { class: 'field' }, h('span', {}, 'Repeat new password'), pw2),
    h('div', { class: 'row end' }, h('button', { class: 'btn gold', type: 'submit' }, 'Change password')));
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const err = validatePassword(pw.value, pw2.value);
    if (err) return toast(err, 'error');
    try { await ctx.db.changePassword(pw.value); form.reset(); toast('Password changed.'); } catch (x) { toast(x.message, 'error'); }
  });
  return h('div', {},
    h('section', { class: 'panel' }, h('h2', {}, 'Help'), SECTIONS.map(([t, items]) => h('details', { class: 'item', open: t === 'Getting started' }, h('summary', {}, h('strong', {}, t)), h('ul', {}, items.map((i) => h('li', {}, i)))))),
    h('section', { class: 'panel' }, h('h2', {}, 'Account'), h('p', { class: 'muted' }, `Signed in as ${ctx.user.email || 'your account'}.`), form,
      h('div', { class: 'row' }, h('button', { class: 'btn ghost', type: 'button', onclick: () => ctx.signOut() }, 'Sign out'))));
}
