// Google Calendar, Sheets and Gmail drafts. Uses the user's own explicit Google consent.
// Nothing that changes Google data runs without an on-screen confirmation.
import { h, clear, toast, confirmDialog, fmtDate } from '../lib/dom.js';
import { callApi } from '../lib/api.js';
import { showError } from './aiResult.js';

const dt = (s) => { const d = new Date(s); return Number.isNaN(d.getTime()) ? s : d.toLocaleString(undefined, { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }); };
const localToIso = (v) => (v ? new Date(v).toISOString() : '');

export function render(ctx) {
  const root = h('div', {});
  const statusBox = h('section', { class: 'panel' });
  const tools = h('div', {});

  // Messages from the Google redirect (#/google?connected=1 or ?error=...)
  const q = new URLSearchParams((location.hash.split('?')[1]) || '');
  const flash = q.get('connected') ? h('p', { class: 'ok' }, 'Google connected.')
    : q.get('error') ? h('p', { class: 'error' }, ({ denied: 'Google access was not granted.', bad_state: 'That connection attempt expired. Please try again.', no_refresh_token: 'Google did not return a lasting permission. Remove this app from your Google account permissions and connect again.', exchange_failed: 'Google would not complete the connection. Please try again.', save_failed: 'The connection could not be saved. Please try again.' })[q.get('error')] || 'The connection failed.') : null;

  async function refreshStatus() {
    clear(statusBox).append(h('h2', {}, 'Google'), ...(flash ? [flash] : []), h('p', { class: 'muted' }, 'Loading…'));
    const r = await callApi('/api/google/status', { method: 'GET' });
    clear(statusBox).append(h('h2', {}, 'Google'), ...(flash ? [flash] : []));
    clear(tools);
    if (!r.ok) {
      statusBox.append(h('div', { class: 'error' }, r.data.message), h('p', { class: 'muted' }, 'Google features are optional. The rest of the app works without them.'));
      return;
    }
    if (!r.data.connected) {
      statusBox.append(
        h('p', {}, 'Connect your Google account to see upcoming calendar events, create events, export your lists to a new Google Sheet, and save email drafts in Gmail.'),
        h('ul', { class: 'plain' }, h('li', {}, 'You choose what to allow on Google\'s own consent screen.'), h('li', {}, 'Nothing is created or changed until you press Confirm in this app.'), h('li', {}, 'Emails are only ever saved as drafts. This app never sends email.')),
        h('button', { class: 'btn gold', type: 'button', onclick: async (e) => {
          e.target.disabled = true;
          const s = await callApi('/api/google/start');
          if (!s.ok) { e.target.disabled = false; return toast(s.data.message, 'error'); }
          window.location.assign(s.data.url);
        } }, 'Connect Google'));
      return;
    }
    statusBox.append(h('p', { class: 'ok' }, `Connected${r.data.email ? ` as ${r.data.email}` : ''}.`),
      h('button', { class: 'btn small ghost danger-text', type: 'button', onclick: async () => {
        if (!(await confirmDialog({ title: 'Disconnect Google?', lines: ['The saved connection is deleted and access is revoked at Google.'], confirmText: 'Disconnect', danger: true }))) return;
        const d = await callApi('/api/google/disconnect');
        if (!d.ok) return toast(d.data.message, 'error');
        toast('Google disconnected.'); refreshStatus();
      } }, 'Disconnect'));
    tools.append(calendarPanel(), sheetsPanel(), gmailPanel());
  }

  function calendarPanel() {
    const list = h('div', { class: 'list' });
    const title = h('input', { type: 'text', maxlength: 200 });
    const start = h('input', { type: 'datetime-local' });
    const end = h('input', { type: 'datetime-local' });
    const loc = h('input', { type: 'text', maxlength: 300 });
    const desc = h('textarea', { rows: 2, maxlength: 2000 });
    async function load() {
      clear(list).append(h('p', { class: 'muted' }, 'Loading events…'));
      const r = await callApi('/api/google/calendar/events?days=14', { method: 'GET' });
      if (!r.ok) return showError(list, r.data.message);
      clear(list);
      if (!r.data.events.length) return list.append(h('p', { class: 'muted empty' }, 'No events in the next 14 days.'));
      r.data.events.forEach((e) => list.append(h('article', { class: 'item' }, h('div', { class: 'item-text' }, h('strong', {}, e.summary), h('div', { class: 'meta' }, h('span', { class: 'chip' }, dt(e.start)), e.location ? h('span', { class: 'chip' }, e.location) : null)))));
    }
    const form = h('form', { class: 'form grid', novalidate: true },
      h('label', { class: 'field wide' }, h('span', {}, 'Event title'), title),
      h('label', { class: 'field' }, h('span', {}, 'Starts'), start), h('label', { class: 'field' }, h('span', {}, 'Ends'), end),
      h('label', { class: 'field wide' }, h('span', {}, 'Location (optional)'), loc),
      h('label', { class: 'field wide' }, h('span', {}, 'Description (optional)'), desc),
      h('div', { class: 'row end wide' }, h('button', { class: 'btn gold', type: 'submit' }, 'Review & create event')));
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!title.value.trim() || !start.value || !end.value) return toast('Add a title, start and end time.', 'error');
      if (new Date(end.value) <= new Date(start.value)) return toast('The end time must be after the start.', 'error');
      const ok = await confirmDialog({ title: 'Create this calendar event?', lines: [title.value.trim(), `${dt(localToIso(start.value))} → ${dt(localToIso(end.value))}`, loc.value.trim() ? `Location: ${loc.value.trim()}` : 'No location', 'It will be added to your primary Google Calendar.'], confirmText: 'Create event' });
      if (!ok) return;
      const r = await callApi('/api/google/calendar/events', { json: { confirm: true, summary: title.value, start: localToIso(start.value), end: localToIso(end.value), location: loc.value, description: desc.value, timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone } });
      if (!r.ok) return toast(r.data.message, 'error');
      toast('Event created.'); form.reset(); load();
    });
    load();
    return h('section', { class: 'panel' }, h('h3', {}, 'Calendar — next 14 days'), list, h('h4', {}, 'New event'), form);
  }

  function sheetsPanel() {
    const out = h('div', {});
    const btn = h('button', { class: 'btn gold', type: 'button' }, 'Export to a new Google Sheet');
    btn.addEventListener('click', async () => {
      btn.disabled = true; clear(out);
      try {
        const [tasks, projects, incidents] = await Promise.all([
          ctx.db.select('tasks', 'select=title,kind,priority,due_date,done&order=created_at.desc&limit=1000'),
          ctx.db.select('projects', 'select=title,status,progress,due_date,next_steps&order=created_at.desc&limit=500'),
          ctx.db.select('incidents', 'select=title,severity,status,created_at&order=created_at.desc&limit=500'),
        ]);
        const ok = await confirmDialog({ title: 'Create a new Google Sheet?', lines: [`${tasks.length} tasks, ${projects.length} projects and ${incidents.length} incidents will be copied into a NEW spreadsheet in your Google Drive.`, 'Existing spreadsheets are never changed.'], confirmText: 'Create sheet' });
        if (!ok) return;
        const r = await callApi('/api/google/sheets/export', { json: { confirm: true, title: `IT export ${new Date().toISOString().slice(0, 10)}`, sheets: [
          { name: 'Tasks', rows: [['Title', 'Type', 'Priority', 'Due', 'Done'], ...tasks.map((t) => [t.title, t.kind, t.priority, t.due_date || '', t.done ? 'yes' : 'no'])] },
          { name: 'Projects', rows: [['Title', 'Status', 'Progress %', 'Target', 'Next steps'], ...projects.map((p) => [p.title, p.status, p.progress, p.due_date || '', p.next_steps || ''])] },
          { name: 'Incidents', rows: [['Title', 'Severity', 'Status', 'Opened'], ...incidents.map((i) => [i.title, i.severity, i.status, i.created_at])] },
        ] } });
        if (!r.ok) return showError(out, r.data.message);
        clear(out).append(h('p', { class: 'ok' }, 'Sheet created. '), h('a', { href: r.data.link, target: '_blank', rel: 'noopener noreferrer' }, 'Open it in Google Sheets'));
      } catch (e) { showError(out, e.message); } finally { btn.disabled = false; }
    });
    return h('section', { class: 'panel' }, h('h3', {}, 'Google Sheets'), h('p', { class: 'muted' }, 'Copies your tasks, projects and incidents into a brand-new spreadsheet.'), btn, out);
  }

  function gmailPanel() {
    const to = h('input', { type: 'email', maxlength: 254, autocomplete: 'off' });
    const subject = h('input', { type: 'text', maxlength: 300 });
    const body = h('textarea', { rows: 6, maxlength: 20000 });
    const form = h('form', { class: 'form', novalidate: true },
      h('label', { class: 'field' }, h('span', {}, 'To'), to), h('label', { class: 'field' }, h('span', {}, 'Subject'), subject), h('label', { class: 'field' }, h('span', {}, 'Message'), body),
      h('div', { class: 'row end' }, h('button', { class: 'btn gold', type: 'submit' }, 'Review & save draft')));
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!to.value.trim() || !subject.value.trim() || !body.value.trim()) return toast('Fill in the recipient, subject and message.', 'error');
      const ok = await confirmDialog({ title: 'Save this as a Gmail draft?', lines: [`To: ${to.value.trim()}`, `Subject: ${subject.value.trim()}`, 'It will be saved in your Gmail Drafts folder. Nothing will be sent.'], confirmText: 'Save draft' });
      if (!ok) return;
      const r = await callApi('/api/google/gmail/draft', { json: { confirm: true, to: to.value, subject: subject.value, body: body.value } });
      if (!r.ok) return toast(r.data.message, 'error');
      toast('Draft saved in Gmail. Nothing was sent.'); form.reset();
    });
    return h('section', { class: 'panel' }, h('h3', {}, 'Gmail drafts'), h('p', { class: 'muted' }, 'Drafts only. Open Gmail to review and send them yourself.'), form);
  }

  root.append(statusBox, tools);
  refreshStatus();
  void fmtDate;
  return root;
}
