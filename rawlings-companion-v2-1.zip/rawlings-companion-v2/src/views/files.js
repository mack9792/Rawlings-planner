// File uploads: validate first, then (optionally) keep a private copy, then process through the AI.
import { h, clear, toast, confirmDialog, fmtDate } from '../lib/dom.js';
import { validateFile, readAttachment, SUPPORTED_LABEL, FILE_LIMITS } from '../lib/validate.js';
import { runAi, resultPanel, showError } from './aiResult.js';

// Content types the private bucket accepts (see supabase/schema.sql), chosen by extension.
const STORED_TYPES = { txt: 'text/plain', md: 'text/markdown', csv: 'text/csv', json: 'application/json', pdf: 'application/pdf', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp' };

const ACTIONS = [
  ['document', 'Summarise it', 'Summarise this document for a busy executive: key points, risks, and open questions.'],
  ['actions', 'Extract action items', 'Extract the action items.'],
  ['document', 'Ask a question…', ''],
];

export function render(ctx) {
  const input = h('input', { type: 'file', accept: '.txt,.md,.csv,.json,.pdf,.png,.jpg,.jpeg,.webp', 'aria-label': 'Choose a file' });
  const status = h('div', { class: 'muted' }, `Supported: ${SUPPORTED_LABEL}. Text up to ${FILE_LIMITS.textBytes / 1000} KB, PDFs and images up to ${FILE_LIMITS.binaryBytes / 1000000} MB.`);
  const keep = h('input', { type: 'checkbox' });
  const question = h('input', { type: 'text', maxlength: 2000, placeholder: 'Your question about the file' });
  const out = h('div', {});
  const files = h('div', { class: 'list' });
  let current = null; // {file, v}

  input.addEventListener('change', () => {
    current = null; clear(out);
    const file = input.files && input.files[0];
    if (!file) return;
    const v = validateFile(file);
    if (!v.ok) { input.value = ''; return showError(status, v.error); }
    current = { file, v };
    clear(status).append(h('div', { class: 'ok' }, `Ready: ${file.name} (${Math.max(1, Math.round(file.size / 1000))} KB)`));
  });

  async function process([task, , defaultPrompt], isQuestion) {
    if (!current) return toast('Choose a file first.', 'error');
    const prompt = isQuestion ? question.value.trim() : defaultPrompt;
    if (!prompt) return toast('Type your question first.', 'error');
    clear(out).append(h('p', { class: 'muted' }, 'Reading the file and asking the AI…'));
    let attachment;
    try { attachment = await readAttachment(current.file, current.v); }
    catch (e) { return showError(out, e.message); }
    const r = await runAi({ task, prompt, attachment });
    if (!r.ok) return showError(out, r.message);
    clear(out).append(resultPanel(ctx, r.data, { task, prompt: `${current.file.name}: ${prompt}` }));
    if (keep.checked) await keepCopy(current);
  }

  async function keepCopy({ file, v }) {
    try {
      const uid = ctx.user.id;
      const path = `${uid}/files/${crypto.randomUUID()}-${file.name.replace(/[^\w.\-]+/g, '_').slice(0, 80)}`;
      const storedType = STORED_TYPES[v.ext] || v.mediaType;
      await ctx.db.uploadFile(path, file, storedType);
      await ctx.db.insert('uploaded_files', { file_path: path, file_name: file.name.slice(0, 255), media_type: storedType, size_bytes: file.size });
      toast('A private copy was kept.'); loadFiles();
    } catch (e) { toast(`The AI answered, but keeping a copy failed: ${e.message}`, 'error'); }
  }

  async function loadFiles() {
    clear(files);
    try {
      const rows = await ctx.db.select('uploaded_files', 'select=*&order=created_at.desc&limit=50');
      if (!rows.length) return files.append(h('p', { class: 'muted empty' }, 'No private copies kept.'));
      for (const f of rows) {
        files.append(h('article', { class: 'item' },
          h('div', { class: 'item-main' }, h('div', { class: 'item-text' }, h('strong', {}, f.file_name), h('div', { class: 'meta' }, h('span', { class: 'chip' }, fmtDate(f.created_at)), h('span', { class: 'chip' }, `${Math.max(1, Math.round(f.size_bytes / 1000))} KB`)))),
          h('div', { class: 'row end' },
            h('button', { class: 'btn small ghost', type: 'button', onclick: async () => {
              try { window.open(await ctx.db.signedUrl(f.file_path, 120), '_blank', 'noopener'); } catch (e) { toast(e.message, 'error'); }
            } }, 'Open'),
            h('button', { class: 'btn small ghost danger-text', type: 'button', onclick: async () => {
              if (!(await confirmDialog({ title: `Delete ${f.file_name}?`, lines: ['The stored copy will be removed.'], confirmText: 'Delete', danger: true }))) return;
              try { await ctx.db.removeFile(f.file_path); await ctx.db.remove('uploaded_files', f.id); loadFiles(); } catch (e) { toast(e.message, 'error'); }
            } }, 'Delete'))));
      }
    } catch (e) { showError(files, e.message); }
  }
  loadFiles();

  return h('div', {},
    h('section', { class: 'panel' }, h('h2', {}, 'Files'),
      h('p', { class: 'muted' }, 'Pick a document, then choose what the AI should do with it. The file is only kept if you tick the box.'),
      h('div', { class: 'form' },
        h('label', { class: 'field' }, h('span', {}, 'File'), input), status,
        h('label', { class: 'inline' }, keep, h('span', {}, 'Also keep a private copy in my account')),
        h('div', { class: 'row wrap' },
          h('button', { class: 'btn gold', type: 'button', onclick: () => process(ACTIONS[0], false) }, ACTIONS[0][1]),
          h('button', { class: 'btn ghost', type: 'button', onclick: () => process(ACTIONS[1], false) }, ACTIONS[1][1])),
        h('div', { class: 'row' }, question, h('button', { class: 'btn ghost', type: 'button', onclick: () => process(ACTIONS[2], true) }, 'Ask')),
        out)),
    h('section', { class: 'panel' }, h('h2', {}, 'Kept files'), files));
}
