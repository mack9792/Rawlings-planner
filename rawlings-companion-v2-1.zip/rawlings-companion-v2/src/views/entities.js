// Generic create / edit / delete panel used for tasks, projects, incidents,
// meetings, notes and decisions. Every request goes through RLS-protected tables.
import { h, clear, toast, confirmDialog, fmtDate } from '../lib/dom.js';

const PRIORITIES = ['Low', 'Normal', 'High', 'Critical'];

export const ENTITIES = {
  tasks: {
    table: 'tasks', label: 'task', plural: 'Tasks & follow-ups', order: 'done.asc,due_date.asc.nullslast,created_at.desc', toggle: 'done',
    fields: [
      { name: 'title', label: 'What needs doing?', type: 'text', required: true, max: 240 },
      { name: 'kind', label: 'Type', type: 'select', options: [['task', 'Task'], ['follow_up', 'Follow-up']], def: 'task' },
      { name: 'priority', label: 'Priority', type: 'select', options: PRIORITIES.map((p) => [p, p]), def: 'Normal' },
      { name: 'due_date', label: 'Due', type: 'date' },
    ],
    summary: (i) => [i.kind === 'follow_up' ? 'Follow-up' : 'Task', i.priority, i.due_date && `due ${fmtDate(i.due_date)}`],
    title: (i) => i.title,
  },
  projects: {
    table: 'projects', label: 'project', plural: 'Projects', order: 'created_at.desc',
    fields: [
      { name: 'title', label: 'Project name', type: 'text', required: true, max: 240 },
      { name: 'status', label: 'Status', type: 'select', options: ['Planned', 'In progress', 'Blocked', 'On hold', 'Done'].map((s) => [s, s]), def: 'In progress' },
      { name: 'progress', label: 'Progress (%)', type: 'number', min: 0, max: 100, def: 0 },
      { name: 'due_date', label: 'Target date', type: 'date' },
      { name: 'next_steps', label: 'Next steps', type: 'textarea', max: 4000 },
      { name: 'details', label: 'Progress notes & issues', type: 'textarea', max: 6000 },
    ],
    summary: (i) => [i.status, `${i.progress}%`, i.due_date && `target ${fmtDate(i.due_date)}`],
    title: (i) => i.title,
    extra: (i) => i.next_steps && `Next: ${i.next_steps}`,
  },
  incidents: {
    table: 'incidents', label: 'incident', plural: 'Incidents', order: 'created_at.desc',
    fields: [
      { name: 'title', label: 'What happened?', type: 'text', required: true, max: 240 },
      { name: 'severity', label: 'Severity', type: 'select', options: ['Low', 'Medium', 'High', 'Critical'].map((s) => [s, s]), def: 'Medium' },
      { name: 'status', label: 'Status', type: 'select', options: ['Open', 'Investigating', 'Mitigated', 'Resolved'].map((s) => [s, s]), def: 'Open' },
      { name: 'project_id', label: 'Related project (optional)', type: 'select', optionsFrom: 'projects', def: '' },
      { name: 'notes', label: 'Notes & next steps', type: 'textarea', max: 6000 },
    ],
    summary: (i) => [i.severity, i.status, `opened ${fmtDate(i.created_at)}`],
    title: (i) => i.title,
    extra: (i) => i.notes,
    beforeSave: (v) => ({ ...v, resolved_at: v.status === 'Resolved' ? new Date().toISOString() : null }),
  },
  meetings: {
    table: 'meetings', label: 'meeting', plural: 'Meetings', order: 'meeting_date.asc,meeting_time.asc.nullslast',
    fields: [
      { name: 'title', label: 'Meeting', type: 'text', required: true, max: 240 },
      { name: 'meeting_date', label: 'Date', type: 'date', required: true },
      { name: 'meeting_time', label: 'Time', type: 'time' },
      { name: 'notes', label: 'Agenda / notes', type: 'textarea', max: 6000 },
    ],
    summary: (i) => [fmtDate(i.meeting_date), i.meeting_time && i.meeting_time.slice(0, 5)],
    title: (i) => i.title,
    extra: (i) => i.notes,
  },
  notes: {
    table: 'notes', label: 'note', plural: 'Notes', order: 'created_at.desc',
    fields: [
      { name: 'title', label: 'Title (optional)', type: 'text', max: 240 },
      { name: 'body', label: 'Note', type: 'textarea', required: true, max: 6000 },
    ],
    summary: (i) => [fmtDate(i.created_at)],
    title: (i) => i.title || (i.body.length > 60 ? `${i.body.slice(0, 60)}…` : i.body),
    extra: (i) => (i.title ? i.body : i.body.length > 60 ? i.body : null),
  },
  decisions: {
    table: 'decisions', label: 'decision', plural: 'Decisions', order: 'created_at.desc',
    fields: [
      { name: 'title', label: 'Decision', type: 'text', required: true, max: 240 },
      { name: 'status', label: 'Status', type: 'select', options: ['Pending', 'Decided', 'Revisit'].map((s) => [s, s]), def: 'Pending' },
      { name: 'decide_by', label: 'Decide by', type: 'date' },
      { name: 'outcome', label: 'Outcome / reasoning', type: 'textarea', max: 4000 },
    ],
    summary: (i) => [i.status, i.decide_by && `by ${fmtDate(i.decide_by)}`],
    title: (i) => i.title,
    extra: (i) => i.outcome,
  },
};

/** Read form values; returns {values} or {error}. Exported for tests. */
export function collectValues(entity, readers) {
  const values = {};
  for (const f of entity.fields) {
    let v = readers[f.name]();
    if (typeof v === 'string') v = v.trim();
    if (f.required && (v === '' || v == null)) return { error: `Please fill in "${f.label}".` };
    if (f.type === 'number') {
      v = v === '' || v == null ? (f.def ?? 0) : Number(v);
      if (!Number.isInteger(v) || v < f.min || v > f.max) return { error: `"${f.label}" must be a whole number from ${f.min} to ${f.max}.` };
    } else if (v === '') v = f.type === 'select' ? (f.def === '' ? null : f.def) : null;
    if (f.max && typeof v === 'string' && v.length > f.max) return { error: `"${f.label}" is too long (max ${f.max} characters).` };
    values[f.name] = v;
  }
  return { values: entity.beforeSave ? entity.beforeSave(values) : values };
}

function buildForm(entity, initial, extraOptions) {
  const readers = {};
  const rows = entity.fields.map((f) => {
    const id = `f-${entity.table}-${f.name}-${Math.random().toString(36).slice(2, 7)}`;
    let input;
    const cur = initial ? initial[f.name] : f.def;
    if (f.type === 'select') {
      const opts = f.optionsFrom ? [['', '— none —'], ...(extraOptions[f.optionsFrom] || [])] : f.options;
      input = h('select', { id }, opts.map(([v, l]) => h('option', { value: v, selected: String(cur ?? '') === String(v) }, l)));
    } else if (f.type === 'textarea') input = h('textarea', { id, rows: 3, maxlength: f.max }, cur || '');
    else input = h('input', { id, type: f.type === 'number' ? 'number' : f.type, min: f.min, max: f.type === 'number' ? f.max : undefined, maxlength: f.type === 'text' ? f.max : undefined, value: cur ?? '' });
    readers[f.name] = () => input.value;
    return h('label', { class: `field ${f.type === 'textarea' || f.name === 'title' ? 'wide' : ''}`, for: id }, h('span', {}, f.label), input);
  });
  return { rows, readers };
}

export function entityPanel(ctx, entity, { filter = '', limit = 100, onChange = () => {}, heading = true, compactForm = false } = {}) {
  const root = h('section', { class: 'panel' });
  const listBox = h('div', { class: 'list' });
  let extraOptions = {};
  let items = [];

  async function loadOptions() {
    const need = entity.fields.filter((f) => f.optionsFrom);
    for (const f of need) {
      const rows = await ctx.db.select(f.optionsFrom, 'select=id,title&order=created_at.desc&limit=100');
      extraOptions[f.optionsFrom] = rows.map((r) => [r.id, r.title]);
    }
  }

  async function reload() {
    clear(listBox).append(h('p', { class: 'muted' }, 'Loading…'));
    try {
      await loadOptions();
      items = await ctx.db.select(entity.table, `select=*&order=${entity.order}&limit=${limit}${filter ? `&${filter}` : ''}`);
      renderList();
    } catch (e) {
      clear(listBox).append(h('div', { class: 'error' }, e.message, ' ', h('button', { class: 'btn small', type: 'button', onclick: reload }, 'Retry')));
    }
  }

  function renderList() {
    clear(listBox);
    if (!items.length) { listBox.append(h('p', { class: 'muted empty' }, `No ${entity.label}s yet.`)); return; }
    for (const item of items) listBox.append(renderItem(item));
  }

  function renderItem(item) {
    const row = h('article', { class: `item ${entity.toggle && item[entity.toggle] ? 'is-done' : ''}` });
    const show = () => {
      clear(row);
      const meta = entity.summary(item).filter(Boolean);
      const extra = entity.extra ? entity.extra(item) : null;
      row.append(
        h('div', { class: 'item-main' },
          entity.toggle ? h('input', { type: 'checkbox', class: 'check', 'aria-label': 'Mark done', checked: !!item[entity.toggle], onchange: async (e) => {
            try { const u = await ctx.db.update(entity.table, item.id, { [entity.toggle]: e.target.checked }); Object.assign(item, u); renderList(); onChange(); }
            catch (err) { e.target.checked = !e.target.checked; toast(err.message, 'error'); }
          } }) : null,
          h('div', { class: 'item-text' },
            h('strong', {}, entity.title(item)),
            h('div', { class: 'meta' }, meta.map((m, i) => h('span', { class: `chip ${i === 1 && /Critical|High|Blocked/.test(String(m)) ? 'warn' : ''}` }, m))),
            extra ? h('p', { class: 'extra' }, extra) : null)),
        h('div', { class: 'row end' },
          h('button', { class: 'btn small ghost', type: 'button', onclick: edit }, 'Edit'),
          h('button', { class: 'btn small ghost danger-text', type: 'button', onclick: async () => {
            if (!(await confirmDialog({ title: `Delete this ${entity.label}?`, lines: ['This cannot be undone.'], confirmText: 'Delete', danger: true }))) return;
            try { await ctx.db.remove(entity.table, item.id); items = items.filter((x) => x.id !== item.id); renderList(); onChange(); toast('Deleted.'); }
            catch (err) { toast(err.message, 'error'); }
          } }, 'Delete')));
    };
    const edit = () => {
      clear(row);
      const { rows, readers } = buildForm(entity, item, extraOptions);
      const form = h('form', { class: 'form grid', novalidate: true }, rows,
        h('div', { class: 'row end wide' },
          h('button', { class: 'btn ghost', type: 'button', onclick: show }, 'Cancel'),
          h('button', { class: 'btn gold', type: 'submit' }, 'Save')));
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const r = collectValues(entity, readers);
        if (r.error) return toast(r.error, 'error');
        try { const u = await ctx.db.update(entity.table, item.id, r.values); Object.assign(item, u); show(); onChange(); toast('Saved.'); }
        catch (err) { toast(err.message, 'error'); }
      });
      row.append(form);
    };
    show();
    return row;
  }

  function addForm() {
    const { rows, readers } = buildForm(entity, null, extraOptions);
    const form = h('form', { class: `form grid add ${compactForm ? 'compact' : ''}`, novalidate: true }, rows,
      h('div', { class: 'row end wide' }, h('button', { class: 'btn gold', type: 'submit' }, `Add ${entity.label}`)));
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const r = collectValues(entity, readers);
      if (r.error) return toast(r.error, 'error');
      try { const created = await ctx.db.insert(entity.table, r.values); items.unshift(created); form.reset(); await reload(); onChange(); toast('Added.'); }
      catch (err) { toast(err.message, 'error'); }
    });
    return form;
  }

  // Options (e.g. project list) must exist before the add form renders.
  const formSlot = h('div', {});
  root.append(...[heading ? h('h2', {}, entity.plural) : null, formSlot, listBox].filter(Boolean));
  loadOptions().catch(() => {}).finally(() => formSlot.append(addForm()));
  reload();
  return root;
}
