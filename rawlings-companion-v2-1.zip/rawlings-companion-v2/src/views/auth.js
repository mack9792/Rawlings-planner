// Sign up, sign in, password recovery (request + set-new-password from the emailed link).
import { h, clear, toast } from '../lib/dom.js';
import { validateEmail, validatePassword } from '../lib/validate.js';

export function renderAuth(db, { recoveryToken, onSignedIn }) {
  let mode = recoveryToken ? 'reset' : 'signin';
  const root = h('div', { class: 'auth-wrap' });
  const msg = h('div', { role: 'alert', class: 'auth-msg' });
  const say = (text, kind = 'error') => { clear(msg).append(h('p', { class: kind }, text)); };

  function draw() {
    clear(root); clear(msg);
    const email = h('input', { type: 'email', autocomplete: 'email', required: true, maxlength: 254 });
    const pw = h('input', { type: 'password', autocomplete: mode === 'signin' ? 'current-password' : 'new-password', maxlength: 72 });
    const pw2 = h('input', { type: 'password', autocomplete: 'new-password', maxlength: 72 });
    const submit = h('button', { class: 'btn gold wide-btn', type: 'submit' }, { signin: 'Sign in', signup: 'Create account', forgot: 'Send recovery email', reset: 'Set new password' }[mode]);
    const form = h('form', { class: 'form', novalidate: true },
      mode !== 'reset' ? h('label', { class: 'field' }, h('span', {}, 'Email'), email) : null,
      mode !== 'forgot' ? h('label', { class: 'field' }, h('span', {}, mode === 'signin' ? 'Password' : 'New password (10+ characters)'), pw) : null,
      mode === 'signup' || mode === 'reset' ? h('label', { class: 'field' }, h('span', {}, 'Repeat password'), pw2) : null,
      submit);
    form.addEventListener('submit', async (e) => {
      e.preventDefault(); clear(msg);
      const emailErr = mode === 'reset' ? null : validateEmail(email.value);
      if (emailErr) return say(emailErr);
      if (mode === 'signup' || mode === 'reset') { const pe = validatePassword(pw.value, pw2.value); if (pe) return say(pe); }
      if (mode === 'signin' && !pw.value) return say('Enter your password.');
      submit.disabled = true;
      try {
        if (mode === 'signin') { await db.signIn(email.value.trim(), pw.value); onSignedIn(); }
        else if (mode === 'signup') {
          const r = await db.signUp(email.value.trim(), pw.value);
          if (r.signedIn) onSignedIn(); else say('Account created. Check your email and click the confirmation link, then sign in.', 'ok');
        } else if (mode === 'forgot') {
          await db.requestPasswordReset(email.value.trim(), `${location.origin}/`);
          say('If that address has an account, a recovery email is on its way. The link expires after a short time.', 'ok');
        } else {
          await db.updatePasswordWithToken(recoveryToken, pw.value);
          history.replaceState(null, '', location.pathname);
          say('Password updated. You can now sign in.', 'ok'); mode = 'signin'; setTimeout(draw, 1500);
        }
      } catch (err) { say(err.message); } finally { submit.disabled = false; }
    });
    const link = (label, m) => h('button', { class: 'link', type: 'button', onclick: () => { mode = m; draw(); } }, label);
    root.append(
      h('div', { class: 'auth-card' }, h('h1', {}, 'Rawlings Executive Companion'), h('p', { class: 'muted' }, { signin: 'Sign in to your private workspace.', signup: 'Create your private account.', forgot: 'Enter your email to receive a recovery link.', reset: 'Choose a new password.' }[mode]),
        form, msg,
        h('div', { class: 'auth-links' }, mode === 'signin' ? [link('Create an account', 'signup'), link('Forgot password?', 'forgot')] : mode !== 'reset' ? link('Back to sign in', 'signin') : null)));
  }
  if (!db.configured()) {
    root.append(h('div', { class: 'auth-card' }, h('h1', {}, 'Almost ready'), h('p', { class: 'notice' }, 'This copy of the app is not connected to a database yet, so sign-in is switched off. Follow the setup guide (README) to connect your Supabase project.')));
    return root;
  }
  draw();
  void toast;
  return root;
}
