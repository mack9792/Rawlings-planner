// Voice notes: record -> stop -> play back -> (discard | transcribe -> edit -> AI -> save).
import { h, clear, toast, confirmDialog, fmtDate } from '../lib/dom.js';
import { VoiceRecorder, recordingSupported, fmtClock, MAX_SECONDS, MAX_BYTES } from '../lib/recorder.js';
import { callApi } from '../lib/api.js';
import { runAi, resultPanel, showError } from './aiResult.js';

export function render(ctx) {
  let clip = null;       // {blob, mimeType, seconds, url}
  let aiText = null;     // latest AI result saved with the note
  const root = h('div', {});

  const timer = h('div', { class: 'clock', 'aria-live': 'off' }, '0:00');
  const startBtn = h('button', { class: 'btn gold big', type: 'button' }, '● Start recording');
  const stopBtn = h('button', { class: 'btn danger big hidden', type: 'button' }, '■ Stop');
  const player = h('div', { class: 'player hidden' });
  const transcriptBox = h('div', { class: 'hidden' });
  const statusSlot = h('div', {});
  const aiOut = h('div', {});
  const saved = h('div', { class: 'list' });

  const rec = new VoiceRecorder({
    onTick: (s) => { timer.textContent = `${fmtClock(s)} / ${fmtClock(MAX_SECONDS)}`; },
    onAutoStop: () => toast('Maximum length reached. Recording stopped.'),
  });
  ctx.onLeave(() => { rec.cancel(); if (clip) URL.revokeObjectURL(clip.url); });

  if (!recordingSupported()) {
    startBtn.disabled = true;
    showError(statusSlot, 'This browser cannot record audio. Try a recent Chrome, Edge, Safari or Firefox. (Recording also requires an https address.)');
  }

  function resetClip() {
    if (clip) URL.revokeObjectURL(clip.url);
    clip = null; aiText = null;
    clear(player).classList.add('hidden'); clear(transcriptBox).classList.add('hidden'); clear(aiOut); clear(statusSlot);
    timer.textContent = '0:00';
    startBtn.classList.remove('hidden');
  }

  startBtn.addEventListener('click', async () => {
    resetClip();
    startBtn.disabled = true;
    try {
      await rec.start();
      startBtn.classList.add('hidden'); stopBtn.classList.remove('hidden'); timer.classList.add('live');
    } catch (e) { showError(statusSlot, e.message); }
    startBtn.disabled = false;
  });

  async function finish() {
    stopBtn.classList.add('hidden'); timer.classList.remove('live');
    try {
      const r = await rec.stop();
      clip = { ...r, url: URL.createObjectURL(r.blob) };
      showClip();
    } catch (e) { showError(statusSlot, e.message); startBtn.classList.remove('hidden'); }
  }
  stopBtn.addEventListener('click', finish);
  rec.onAutoStop = () => { toast('Maximum length reached. Recording stopped.'); setTimeout(finish, 50); };

  function showClip() {
    startBtn.classList.remove('hidden');
    startBtn.textContent = '● Record again';
    timer.textContent = fmtClock(clip.seconds);
    const tooBig = clip.blob.size > MAX_BYTES;
    const transcribeBtn = h('button', { class: 'btn gold', type: 'button', disabled: tooBig }, 'Transcribe');
    clear(player).classList.remove('hidden');
    player.append(
      h('audio', { controls: true, src: clip.url, 'aria-label': 'Playback of your recording' }),
      ...(tooBig ? [h('p', { class: 'notice' }, 'This recording is too large to transcribe (over about 4 MB). Record a shorter note.')] : []),
      h('div', { class: 'row wrap' },
        transcribeBtn,
        h('button', { class: 'btn ghost', type: 'button', onclick: async () => {
          if (await confirmDialog({ title: 'Discard this recording?', lines: ['It has not been saved and cannot be recovered.'], confirmText: 'Discard', danger: true })) { resetClip(); startBtn.textContent = '● Start recording'; }
        } }, 'Discard'),
        h('button', { class: 'btn ghost', type: 'button', onclick: () => save() }, 'Save audio only')));
    transcribeBtn.addEventListener('click', () => transcribe(transcribeBtn));
  }

  async function transcribe(btn) {
    btn.disabled = true; btn.textContent = 'Transcribing…';
    clear(statusSlot);
    const r = await callApi('/api/transcribe', { body: clip.blob, contentType: clip.mimeType });
    btn.disabled = false; btn.textContent = 'Transcribe';
    if (!r.ok) return showError(statusSlot, r.data.message || 'Transcription failed.');
    if (r.data.empty) { showTranscript(''); return showError(statusSlot, 'No speech was detected. You can type the note yourself below, or record again.'); }
    showTranscript(r.data.text);
  }

  let transcriptArea;
  function showTranscript(text) {
    transcriptArea = h('textarea', { rows: 7, maxlength: 40000, 'aria-label': 'Transcript (editable)' }, text);
    clear(transcriptBox).classList.remove('hidden');
    const procBtn = h('button', { class: 'btn gold', type: 'button' }, 'Summarise & list follow-ups');
    const actBtn = h('button', { class: 'btn ghost', type: 'button' }, 'Extract action items');
    const run = (btn, label, task, prompt) => async () => {
      const t = transcriptArea.value.trim();
      if (!t) return toast('The transcript is empty.', 'error');
      btn.disabled = true; btn.textContent = 'Thinking…'; clear(aiOut);
      const r = await runAi({ task, prompt, attachment: { kind: 'text', name: 'voice-note-transcript', text: t } });
      btn.disabled = false; btn.textContent = label;
      if (!r.ok) return showError(aiOut, r.message);
      if (task === 'voice') aiText = r.data.text;
      clear(aiOut).append(resultPanel(ctx, r.data, null));
    };
    procBtn.addEventListener('click', run(procBtn, 'Summarise & list follow-ups', 'voice', 'Clean up this voice note, give a short summary, then list decisions and follow-ups.'));
    actBtn.addEventListener('click', run(actBtn, 'Extract action items', 'actions', 'Extract the action items.'));
    transcriptBox.append(h('h3', {}, 'Transcript — check and correct it'), transcriptArea,
      h('div', { class: 'row wrap' }, procBtn, actBtn, h('button', { class: 'btn ghost', type: 'button', onclick: () => save() }, 'Save note')));
  }

  async function save() {
    if (!clip) return;
    const transcript = transcriptArea ? transcriptArea.value.trim() : '';
    try {
      let audio_path = null;
      if (clip.blob.size <= 5_000_000) {
        audio_path = `${ctx.user.id}/voice/${crypto.randomUUID()}.${clip.mimeType.includes('mp4') ? 'm4a' : clip.mimeType.includes('ogg') ? 'ogg' : 'webm'}`;
        await ctx.db.uploadFile(audio_path, clip.blob, clip.mimeType);
      }
      await ctx.db.insert('voice_notes', { audio_path, duration_s: clip.seconds, transcript: transcript || null, ai_result: aiText });
      toast('Voice note saved.');
      resetClip(); startBtn.textContent = '● Start recording';
      loadSaved();
    } catch (e) { toast(`Could not save: ${e.message}`, 'error'); }
  }

  async function loadSaved() {
    clear(saved);
    try {
      const rows = await ctx.db.select('voice_notes', 'select=*&order=created_at.desc&limit=30');
      if (!rows.length) return saved.append(h('p', { class: 'muted empty' }, 'No saved voice notes yet.'));
      for (const n of rows) {
        const audioSlot = h('div', {});
        saved.append(h('details', { class: 'item' },
          h('summary', {}, h('strong', {}, fmtDate(n.created_at)), ' ', h('span', { class: 'chip' }, n.duration_s != null ? fmtClock(n.duration_s) : 'no audio')),
          n.transcript ? h('pre', { class: 'answer' }, n.transcript) : h('p', { class: 'muted' }, 'No transcript saved.'),
          n.ai_result ? h('details', {}, h('summary', {}, 'AI summary'), h('pre', { class: 'answer' }, n.ai_result)) : null,
          audioSlot,
          h('div', { class: 'row end' },
            n.audio_path ? h('button', { class: 'btn small ghost', type: 'button', onclick: async (e) => {
              e.target.disabled = true;
              try { clear(audioSlot).append(h('audio', { controls: true, src: await ctx.db.signedUrl(n.audio_path, 300) })); } catch (err) { toast(err.message, 'error'); e.target.disabled = false; }
            } }, 'Load audio') : null,
            h('button', { class: 'btn small ghost danger-text', type: 'button', onclick: async () => {
              if (!(await confirmDialog({ title: 'Delete this voice note?', lines: ['The recording and transcript will be removed.'], confirmText: 'Delete', danger: true }))) return;
              try { if (n.audio_path) await ctx.db.removeFile(n.audio_path); await ctx.db.remove('voice_notes', n.id); loadSaved(); } catch (err) { toast(err.message, 'error'); }
            } }, 'Delete'))));
      }
    } catch (e) { showError(saved, e.message); }
  }
  loadSaved();

  root.append(
    h('section', { class: 'panel' }, h('h2', {}, 'Voice notes'),
      h('p', { class: 'muted' }, `Record up to ${MAX_SECONDS / 60} minutes. Your browser will ask for microphone permission. Audio is only sent for transcription when you press Transcribe.`),
      h('div', { class: 'recorder' }, timer, h('div', { class: 'row center' }, startBtn, stopBtn)),
      statusSlot, player, transcriptBox, aiOut),
    h('section', { class: 'panel' }, h('h2', {}, 'Saved voice notes'), saved));
  return root;
}
