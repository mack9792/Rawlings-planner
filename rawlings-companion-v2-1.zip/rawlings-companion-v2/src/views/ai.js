// AI Command Center: ask anything, document help on pasted text, action-item extraction, saved history.
import { h, clear, toast, confirmDialog, fmtDate } from '../lib/dom.js';
import { runAi, resultPanel, showError } from './aiResult.js';

const MODES = {
  chat: { label: 'Ask anything', task: 'chat', hint: 'e.g. Draft a short incident update for the leadership team about the VPN outage.' },
  document: { label: 'Help with a document', task: 'document', hint: 'What should I do with the text below? e.g. Summarise the risks in 5 bullet points.' },
  actions: { label: 'Extract action items', task: 'actions', hint: '' },
};

export function render(ctx) {
  let mode = 'chat';
  const modeSel = h('select', { 'aria-label': 'What do you want to do?' }, Object.entries(MODES).map(([k, m]) => h('option', { value: k }, m.label)));
  const prompt = h('textarea', { rows: 4, maxlength: 20000, placeholder: MODES.chat.hint });
  const docLabel = h('label', { class: 'field wide hidden' }, h('span', {}, 'Paste the document or notes here'), h('textarea', { rows: 8, maxlength: 150000 }));
  const docText = docLabel.querySelector('textarea');
  const promptLabel = h('label', { class: 'field wide' }, h('span', {}, 'Your request'), prompt);
  const out = h('div', {});
  const send = h('button', { class: 'btn gold', type: 'submit' }, 'Send');
  const history = h('div', { class: 'list' });

  modeSel.addEventListener('change', () => {
    mode = modeSel.value;
    prompt.placeholder = MODES[mode].hint;
    docLabel.classList.toggle('hidden', mode === 'chat');
    promptLabel.classList.toggle('hidden', mode === 'actions');
  });

  const form = h('form', { class: 'form', novalidate: true }, h('label', { class: 'field' }, h('span', {}, 'Mode'), modeSel), promptLabel, docLabel, h('div', { class: 'row end' }, send));
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const m = MODES[mode];
    let body;
    let saved;
    if (mode === 'chat') {
      if (!prompt.value.trim()) return toast('Type a request first.', 'error');
      body = { task: 'chat', prompt: prompt.value }; saved = prompt.value;
    } else if (mode === 'document') {
      if (!docText.value.trim()) return toast('Paste the document text first.', 'error');
      if (!prompt.value.trim()) return toast('Say what you want done with it.', 'error');
      body = { task: 'document', prompt: prompt.value, attachment: { kind: 'text', name: 'pasted-text', text: docText.value } }; saved = prompt.value;
    } else {
      if (!docText.value.trim()) return toast('Paste the notes to read first.', 'error');
      body = { task: 'actions', prompt: 'Extract the action items.', attachment: { kind: 'text', name: 'pasted-text', text: docText.value } }; saved = 'Extract action items from pasted text';
    }
    send.disabled = true; send.textContent = 'Thinking…';
    clear(out).append(h('p', { class: 'muted' }, 'Working on it…'));
    const r = await runAi(body);
    send.disabled = false; send.textContent = 'Send';
    if (!r.ok) return showError(out, r.message);
    clear(out).append(resultPanel(ctx, r.data, { task: m.task, prompt: saved, onSaved: loadHistory }));
  });

  async function loadHistory() {
    clear(history);
    try {
      const rows = await ctx.db.select('ai_history', 'select=*&order=created_at.desc&limit=20');
      if (!rows.length) return history.append(h('p', { class: 'muted empty' }, 'Nothing saved yet. Use "Save to history" on an answer you want to keep.'));
      for (const r of rows) {
        history.append(h('details', { class: 'item' },
          h('summary', {}, h('strong', {}, r.prompt.length > 70 ? `${r.prompt.slice(0, 70)}…` : r.prompt), ' ', h('span', { class: 'chip' }, fmtDate(r.created_at))),
          h('pre', { class: 'answer' }, r.response),
          h('div', { class: 'row end' }, h('button', { class: 'btn small ghost danger-text', type: 'button', onclick: async () => {
            if (!(await confirmDialog({ title: 'Delete this saved answer?', confirmText: 'Delete', danger: true }))) return;
            try { await ctx.db.remove('ai_history', r.id); loadHistory(); } catch (e) { toast(e.message, 'error'); }
          } }, 'Delete'))));
      }
    } catch (e) { showError(history, e.message); }
  }
  loadHistory();

  return h('div', {},
    h('section', { class: 'panel' }, h('h2', {}, 'AI Command Center'),
      h('p', { class: 'muted' }, 'Answers come from a real AI model. If something goes wrong you will see the real error, never a made-up answer. Check important facts before acting on them.'),
      form, out),
    h('section', { class: 'panel' }, h('h2', {}, 'Saved answers'), history));
}
