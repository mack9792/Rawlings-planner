// Shared AI plumbing: calling the server, and showing the answer honestly.
import { h, clear, toast } from '../lib/dom.js';
import { callApi } from '../lib/api.js';

/** Calls /api/ai. Never fabricates: on any failure returns {ok:false, message}. */
export async function runAi(payload) {
  const r = await callApi('/api/ai', { json: payload });
  if (!r.ok) return { ok: false, message: r.data.message || 'The AI request failed.', code: r.data.error };
  return { ok: true, data: r.data };
}

export function itemToTask(i) {
  const iso = i.due && /^\d{4}-\d{2}-\d{2}$/.test(i.due) ? i.due : null;
  const bits = [i.title, i.owner ? `(${i.owner})` : null, !iso && i.due ? `— due ${i.due}` : null].filter(Boolean).join(' ');
  return { title: bits.slice(0, 240), kind: 'task', priority: i.priority || 'Normal', due_date: iso };
}

/**
 * Renders an AI answer. `save` is {task, prompt} to enable "Save to history".
 */
export function resultPanel(ctx, res, save) {
  const box = h('div', { class: 'result' });
  if (res.warning) box.append(h('p', { class: 'notice' }, res.warning));
  box.append(h('pre', { class: 'answer' }, res.text));

  const actions = h('div', { class: 'row' },
    h('button', { class: 'btn small ghost', type: 'button', onclick: async () => {
      try { await navigator.clipboard.writeText(res.text); toast('Copied.'); } catch { toast('Could not copy. Select the text and copy it manually.', 'error'); }
    } }, 'Copy'));
  if (save) {
    const btn = h('button', { class: 'btn small ghost', type: 'button', onclick: async () => {
      btn.disabled = true;
      try { await ctx.db.insert('ai_history', { task: save.task, prompt: save.prompt.slice(0, 20000), response: res.text.slice(0, 40000) }); toast('Saved to history.'); if (save.onSaved) save.onSaved(); }
      catch (e) { btn.disabled = false; toast(e.message, 'error'); }
    } }, 'Save to history');
    actions.append(btn);
  }
  box.append(actions);

  if (Array.isArray(res.items)) {
    if (!res.items.length) box.append(h('p', { class: 'muted' }, 'No action items were found.'));
    else {
      const checks = res.items.map((i) => ({ i, el: h('input', { type: 'checkbox', checked: true }) }));
      const addBtn = h('button', { class: 'btn gold', type: 'button' }, 'Add selected to my tasks');
      addBtn.addEventListener('click', async () => {
        const chosen = checks.filter((c) => c.el.checked).map((c) => c.i);
        if (!chosen.length) return toast('Tick at least one item.', 'error');
        addBtn.disabled = true;
        let ok = 0;
        for (const i of chosen) { try { await ctx.db.insert('tasks', itemToTask(i)); ok += 1; } catch (e) { toast(e.message, 'error'); break; } }
        addBtn.disabled = false;
        if (ok) toast(`${ok} task${ok === 1 ? '' : 's'} added.`);
      });
      box.append(h('h4', {}, 'Action items found'),
        h('ul', { class: 'actions' }, checks.map(({ i, el }) => h('li', {}, h('label', { class: 'inline' }, el, h('span', {}, h('strong', {}, i.title), ' ', h('span', { class: 'muted' }, [i.owner && `Owner: ${i.owner}`, i.due && `Due: ${i.due}`, i.priority].filter(Boolean).join(' · '))))))),
        addBtn);
    }
  }
  return box;
}

export function busyButton(btn, label, fn) {
  btn.addEventListener('click', async () => {
    const old = btn.textContent;
    btn.disabled = true; btn.textContent = label;
    try { await fn(); } finally { btn.disabled = false; btn.textContent = old; }
  });
  return btn;
}

export function showError(slot, message) {
  clear(slot).append(h('div', { class: 'error', role: 'alert' }, message));
}
