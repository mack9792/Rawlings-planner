-- =====================================================================
-- Rawlings Executive Companion — fresh database setup
-- Run ONCE in a NEW Supabase project owned by Rawlings:
--   Supabase dashboard -> SQL Editor -> New query -> paste this file -> Run.
-- Safe to re-run: every statement is idempotent.
--
-- Security model
--   * Every table has Row Level Security (RLS) ON.
--   * A signed-in user can only see/change rows where user_id = their own id.
--   * Anonymous (not signed in) visitors get no access at all.
--   * google_tokens has NO client policy: only server functions (service
--     role key) can read it. The browser can never see Google tokens.
--   * The file bucket is private; each user can only touch files under
--     a folder named with their own user id.
-- There are no admin accounts, triggers, or hidden access for anyone else.
-- =====================================================================

-- ---------- Tables ----------------------------------------------------

create table if not exists public.tasks (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null default auth.uid() references auth.users(id) on delete cascade,
  title       text not null check (char_length(title) between 1 and 240),
  kind        text not null default 'task' check (kind in ('task','follow_up')),
  priority    text not null default 'Normal' check (priority in ('Low','Normal','High','Critical')),
  due_date    date,
  done        boolean not null default false,
  created_at  timestamptz not null default now()
);

create table if not exists public.projects (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null default auth.uid() references auth.users(id) on delete cascade,
  title       text not null check (char_length(title) between 1 and 240),
  status      text not null default 'In progress'
              check (status in ('Planned','In progress','Blocked','On hold','Done')),
  progress    integer not null default 0 check (progress between 0 and 100),
  next_steps  text check (next_steps is null or char_length(next_steps) <= 4000),
  details     text check (details is null or char_length(details) <= 6000),
  due_date    date,
  created_at  timestamptz not null default now()
);

create table if not exists public.incidents (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null default auth.uid() references auth.users(id) on delete cascade,
  project_id  uuid references public.projects(id) on delete set null,
  title       text not null check (char_length(title) between 1 and 240),
  severity    text not null default 'Medium' check (severity in ('Low','Medium','High','Critical')),
  status      text not null default 'Open' check (status in ('Open','Investigating','Mitigated','Resolved')),
  notes       text check (notes is null or char_length(notes) <= 6000),
  created_at  timestamptz not null default now(),
  resolved_at timestamptz
);

create table if not exists public.meetings (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null default auth.uid() references auth.users(id) on delete cascade,
  title         text not null check (char_length(title) between 1 and 240),
  meeting_date  date not null,
  meeting_time  time,
  notes         text check (notes is null or char_length(notes) <= 6000),
  created_at    timestamptz not null default now()
);

create table if not exists public.notes (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null default auth.uid() references auth.users(id) on delete cascade,
  title       text check (title is null or char_length(title) <= 240),
  body        text not null check (char_length(body) between 1 and 6000),
  created_at  timestamptz not null default now()
);

create table if not exists public.decisions (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null default auth.uid() references auth.users(id) on delete cascade,
  title       text not null check (char_length(title) between 1 and 240),
  outcome     text check (outcome is null or char_length(outcome) <= 4000),
  status      text not null default 'Pending' check (status in ('Pending','Decided','Revisit')),
  decide_by   date,
  created_at  timestamptz not null default now()
);

-- Saved AI answers (only what the user chooses to keep).
create table if not exists public.ai_history (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null default auth.uid() references auth.users(id) on delete cascade,
  task        text not null check (task in ('chat','document','actions','voice')),
  prompt      text not null check (char_length(prompt) <= 20000),
  response    text not null check (char_length(response) <= 40000),
  created_at  timestamptz not null default now()
);

-- Voice notes: audio lives in the private bucket, text lives here.
create table if not exists public.voice_notes (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null default auth.uid() references auth.users(id) on delete cascade,
  audio_path    text check (audio_path is null or char_length(audio_path) <= 400),
  duration_s    integer check (duration_s is null or duration_s between 0 and 3600),
  transcript    text check (transcript is null or char_length(transcript) <= 40000),
  ai_result     text check (ai_result is null or char_length(ai_result) <= 40000),
  created_at    timestamptz not null default now()
);

-- Optional private copies of uploaded documents.
create table if not exists public.uploaded_files (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null default auth.uid() references auth.users(id) on delete cascade,
  file_path   text not null check (char_length(file_path) <= 400),
  file_name   text not null check (char_length(file_name) <= 255),
  media_type  text not null check (char_length(media_type) <= 100),
  size_bytes  integer not null check (size_bytes >= 0),
  created_at  timestamptz not null default now()
);

-- Google refresh tokens, encrypted by the server. NO client access (see below).
create table if not exists public.google_tokens (
  user_id         uuid primary key references auth.users(id) on delete cascade,
  refresh_token   text not null,          -- AES-256-GCM ciphertext, never plaintext
  scopes          text not null default '',
  google_email    text,
  updated_at      timestamptz not null default now()
);

create index if not exists tasks_user_idx       on public.tasks(user_id, done, due_date);
create index if not exists projects_user_idx    on public.projects(user_id, status);
create index if not exists incidents_user_idx   on public.incidents(user_id, status);
create index if not exists meetings_user_idx    on public.meetings(user_id, meeting_date);
create index if not exists notes_user_idx       on public.notes(user_id, created_at desc);
create index if not exists decisions_user_idx   on public.decisions(user_id, status);
create index if not exists ai_history_user_idx  on public.ai_history(user_id, created_at desc);
create index if not exists voice_notes_user_idx on public.voice_notes(user_id, created_at desc);
create index if not exists uploaded_files_user_idx on public.uploaded_files(user_id, created_at desc);

-- ---------- Row Level Security ---------------------------------------

do $$
declare t text;
begin
  foreach t in array array[
    'tasks','projects','incidents','meetings','notes',
    'decisions','ai_history','voice_notes','uploaded_files'
  ] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('revoke all on public.%I from anon', t);
    execute format('grant select, insert, update, delete on public.%I to authenticated', t);
    execute format('drop policy if exists "own rows" on public.%I', t);
    execute format(
      'create policy "own rows" on public.%I for all to authenticated '
      'using (user_id = (select auth.uid())) '
      'with check (user_id = (select auth.uid()))', t);
  end loop;
end $$;

-- A project referenced by an incident must belong to the same user.
create or replace function public.incident_project_same_owner()
returns trigger language plpgsql as $$
begin
  if new.project_id is not null and not exists (
    select 1 from public.projects p
    where p.id = new.project_id and p.user_id = new.user_id
  ) then
    raise exception 'project does not belong to this user';
  end if;
  return new;
end $$;

drop trigger if exists incident_project_owner_check on public.incidents;
create trigger incident_project_owner_check
  before insert or update on public.incidents
  for each row execute function public.incident_project_same_owner();

-- google_tokens: RLS on, deliberately NO policy, no grants to client roles.
alter table public.google_tokens enable row level security;
revoke all on public.google_tokens from anon, authenticated;

-- ---------- Private file storage -------------------------------------

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'private-files', 'private-files', false, 5242880,
  array['audio/webm','audio/ogg','audio/mp4','audio/mpeg','audio/wav',
        'application/pdf','image/png','image/jpeg','image/webp',
        'text/plain','text/markdown','text/csv','application/json']
)
on conflict (id) do update
  set public = false,
      file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "own files read"   on storage.objects;
drop policy if exists "own files insert" on storage.objects;
drop policy if exists "own files update" on storage.objects;
drop policy if exists "own files delete" on storage.objects;

create policy "own files read" on storage.objects for select to authenticated
  using (bucket_id = 'private-files'
         and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "own files insert" on storage.objects for insert to authenticated
  with check (bucket_id = 'private-files'
         and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "own files update" on storage.objects for update to authenticated
  using (bucket_id = 'private-files'
         and (storage.foldername(name))[1] = (select auth.uid())::text)
  with check (bucket_id = 'private-files'
         and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "own files delete" on storage.objects for delete to authenticated
  using (bucket_id = 'private-files'
         and (storage.foldername(name))[1] = (select auth.uid())::text);
