-- =====================================================================
-- Data-isolation self-check. Run AFTER schema.sql, in the Supabase SQL
-- Editor of Rawlings' own project. It creates two throw-away users,
-- proves user B cannot see/change/insert-as user A, then rolls EVERYTHING
-- back so no test data remains. Every check either passes or raises an
-- exception, so "Success" at the end means all checks passed.
-- NOT YET EXECUTED by the builder: no database was available. Run it once.
-- =====================================================================
begin;

do $$
declare
  a uuid := gen_random_uuid();
  b uuid := gen_random_uuid();
  n int;
begin
  insert into auth.users (id, email, aud, role, instance_id)
  values (a, 'iso-a@example.invalid', 'authenticated', 'authenticated', '00000000-0000-0000-0000-000000000000'),
         (b, 'iso-b@example.invalid', 'authenticated', 'authenticated', '00000000-0000-0000-0000-000000000000');

  -- act as user A and create a row
  perform set_config('request.jwt.claim.sub', a::text, true);
  perform set_config('request.jwt.claims', json_build_object('sub', a, 'role', 'authenticated')::text, true);
  set local role authenticated;
  insert into public.tasks (title) values ('A private task');
  select count(*) into n from public.tasks;
  if n <> 1 then raise exception 'FAIL: A should see own task, saw %', n; end if;

  -- act as user B: must see nothing, change nothing
  reset role;
  perform set_config('request.jwt.claim.sub', b::text, true);
  perform set_config('request.jwt.claims', json_build_object('sub', b, 'role', 'authenticated')::text, true);
  set local role authenticated;
  select count(*) into n from public.tasks;
  if n <> 0 then raise exception 'FAIL: B can read A rows (%)', n; end if;
  update public.tasks set title = 'hijacked';
  get diagnostics n = row_count;
  if n <> 0 then raise exception 'FAIL: B updated A rows (%)', n; end if;
  delete from public.tasks;
  get diagnostics n = row_count;
  if n <> 0 then raise exception 'FAIL: B deleted A rows (%)', n; end if;
  begin
    insert into public.tasks (user_id, title) values (a, 'forged');
    raise exception 'FAIL: B inserted a row owned by A';
  exception when insufficient_privilege or check_violation then
    null; -- expected: RLS rejected it
  end;

  -- Google tokens must be unreachable from the client role
  begin
    perform 1 from public.google_tokens;
    raise exception 'FAIL: client role can read google_tokens';
  exception when insufficient_privilege then
    null; -- expected
  end;

  -- anonymous role gets nothing
  reset role;
  set local role anon;
  begin
    perform 1 from public.tasks;
    raise exception 'FAIL: anon can read tasks';
  exception when insufficient_privilege then
    null; -- expected
  end;
  reset role;
end $$;

select 'Success: all isolation checks passed' as result;
rollback;
