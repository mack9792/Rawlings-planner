# Rawlings Executive Companion

A private AI workspace for Rawlings, Head of IT: dashboard, projects and incidents, AI assistant, voice notes, file help, private records, optional Google Calendar / Sheets / Gmail drafts, and a personal note.

It is a normal web app (static pages + three small server functions + a Supabase database). A single HTML file cannot do secure sign-in, keep an AI key secret or protect private data, so there are a few **one-time setup steps** below. They take about 45 minutes and everything ends up in accounts that **Rawlings owns**. Nobody else has access.

---

## What has and has not been verified

| Area | Status |
|---|---|
| Screens, navigation, mobile layout, recording/stop/playback, transcript editing, upload validation, error messages | Tested in a real browser (Chromium) against a **simulated** backend |
| Sign-up / login / password-reset logic, session refresh | Unit-tested against a simulated Supabase. **Not yet tried on a real Supabase project** |
| Database tables, access rules, private file folders | Applied twice and tested on a local PostgreSQL with stand-ins for Supabase's login and storage tables: users cannot see, change or forge each other's rows; Google tokens are unreachable from the browser. **Not yet run on a real Supabase project** (run `supabase/rls_isolation_check.sql` there once) |
| AI and transcription server code | Unit-tested including every failure type (bad key, rate limit, outage, timeout, empty/garbled answer). **Never called with a real key** |
| Google Calendar / Sheets / Gmail drafts | Unit-tested (confirmation required, encrypted token storage, no "send" capability). **Needs your Google authorisation to test live** |
| Production build, security headers, "no secrets in the browser" | Tested |
| The personal note | **Included** in `content/bibish-note.txt`; its exact wording is locked by automated tests and a browser check |

Until each "not yet tried" item has been tried on your accounts, treat it as unproven. The app always shows honest messages when something is not configured. It never fakes a result.

---

## One-time setup

### 1. Create your Supabase project (database + login) — free
1. Sign up at supabase.com and create a **New project** (choose a region near Bahrain, e.g. Europe or Mumbai). Save the database password.
2. Open **SQL Editor → New query**, paste all of `supabase/schema.sql`, press **Run**. Safe to run again.
3. New query again: paste `supabase/rls_isolation_check.sql` and Run. It must end with `Success: all isolation checks passed` (it leaves no data behind).
4. **Project Settings → API**: copy the **Project URL**, the **anon/publishable key** (public) and the **service_role/secret key** (private, never share).
5. **Authentication → URL Configuration**: set *Site URL* to your Netlify address (step 3) and add the same address under *Redirect URLs*. This makes password-reset links work.
6. Optional but recommended: **Authentication → Sign In / Providers → Email**: turn **off** "Allow new users to sign up" after you have created your own account, so nobody else can register.

### 2. Get the two API keys
- **AI (Anthropic)**: console.anthropic.com → API keys. This is **pay-per-use** (no free tier); normal use costs little. Set a monthly spend limit there.
- **Voice transcription (Groq)**: console.groq.com → API keys. Groq's docs list `whisper-large-v3-turbo` with a free tier (25 MB file limit). The exact free-tier request limits were not confirmed, so check Groq's rate-limits page. Voice notes in this app are capped near 4 MB (about 10 minutes).

### 3. Deploy on Netlify
1. Put this folder in a GitHub repository you own (do **not** commit a `.env` file).
2. netlify.com → **Add new site → Import from Git**. Build settings are read from `netlify.toml`; nothing to change.
3. **Site configuration → Environment variables**: add every name from `.env.example` with your own values:
   `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `ANTHROPIC_API_KEY`, `GROQ_API_KEY`, `SITE_URL` (and the Google ones in step 4 if you want them).
   Strongly recommended: also set `ALLOWED_EMAILS` to Rawlings' own email so nobody else can spend your AI credits, even if sign-ups are open.
   The build stops with a clear message if a secret key is pasted into the public `SUPABASE_ANON_KEY` slot.
4. Deploy. Open the site, **Create an account**, confirm the email, sign in.

### 4. Google (optional)
1. console.cloud.google.com → new project → enable **Google Calendar API**, **Google Sheets API**, **Gmail API**.
2. **OAuth consent screen**: External; add yourself as a test user. Note: while an app stays in "Testing", Google may expire the connection after about 7 days; set it to "In production" (it will show an "unverified app" warning that you can accept, since you are the only user) to avoid reconnecting weekly.
3. **Credentials → OAuth client ID → Web application**. Authorised redirect URI: `https://YOUR-SITE/api/google/callback`.
4. In Netlify add `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `TOKEN_ENC_KEY` (generate with `node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"`) and `SITE_URL`. Redeploy.
5. In the app: **Google → Connect**. You will always see a confirmation before an event, sheet or Gmail **draft** is created. This app's code only ever creates drafts and never calls Gmail's send function. (Google's `gmail.compose` permission technically also allows sending, and Google has no drafts-only option, so the stored token is encrypted and can be revoked from your Google account at any time.)

### 5. The personal note
The note is already included in `content/bibish-note.txt` (title "A Little Note from Your Bibish ❤️" is built in). Do not edit that file unless you want to change the message; automated tests check its exact wording.

---

## Using it
See the **Help** page inside the app. Short version: add tasks/projects/incidents; use **AI** for questions, document help and action items; **Voice** to record, play back, transcribe, correct, summarise and save; **Files** for TXT/MD/CSV/JSON/PDF/PNG/JPG/WebP (Word/Excel: save as PDF first).

## Privacy and ownership
- Every database row belongs to one user and is protected by database rules; the file bucket is private and per-user.
- AI and Groq keys, the Supabase service key and Google secrets exist only in Netlify's server settings.
- Google refresh tokens are stored encrypted in a table the browser cannot read.
- No analytics, trackers, third-party scripts, hidden admin accounts or back doors. The strict security policy in `netlify.toml` blocks third-party code.
- Text you send to AI, and recordings you transcribe, go to Anthropic and Groq respectively, only when you press the button.

## For developers
```
npm test            # 60+ unit/integration tests, zero dependencies
npm run build       # writes dist/
npm run verify:dist # checks the build (imports resolve, no secrets leaked)
node tests/e2e/smoke.mjs   # browser test (needs Playwright + Chromium)
TEST_PG_URL=... npm test   # also runs the SQL checks on a scratch Postgres loaded with tests/db/supabase_stub.sql
```
Layout: `src/` browser app (no bundler) · `netlify/` server functions · `supabase/` SQL · `tests/` · `content/` personal note.
Known limits: Word/Excel files unsupported; voice notes ≤ ~10 min; large PDFs/images ≤ 3 MB; no offline mode.
