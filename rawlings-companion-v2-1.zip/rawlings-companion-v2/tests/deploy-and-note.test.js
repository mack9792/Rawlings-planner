import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync, statSync, mkdtempSync, writeFileSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { build, looksSecret } from '../scripts/build.mjs';
import { verifyDist } from '../scripts/verify-dist.mjs';
import { parseNote, NOTE_TITLE } from '../src/views/note.js';

const root = new URL('..', import.meta.url).pathname;
const read = (f) => readFileSync(path.join(root, f), 'utf8');
const walk = (d) => readdirSync(d).flatMap((f) => { const p = path.join(d, f); return f === 'node_modules' || f === 'dist' || f.startsWith('.git') ? [] : statSync(p).isDirectory() ? walk(p) : [p]; });
const quiet = () => {};

test('netlify.toml: build, publish, functions, strict headers', () => {
  const t = read('netlify.toml');
  assert.match(t, /publish = "dist"/); assert.match(t, /functions = "netlify\/functions"/); assert.match(t, /command = "node scripts\/build\.mjs"/);
  assert.match(t, /script-src 'self'/); assert.equal(/unsafe-inline|unsafe-eval/.test(t), false);
  assert.match(t, /frame-ancestors 'none'/); assert.match(t, /microphone=\(self\)/);
  assert.match(t, /Strict-Transport-Security/);
  assert.equal(/https:\/\/(?!\*\.supabase\.co)/.test(t.match(/Content-Security-Policy = "[^"]*"/)[0]), false, 'CSP allows no third-party hosts other than Supabase');
});
test('every function route is declared and requires the shared auth helper', () => {
  for (const f of ['ai', 'transcribe', 'google']) assert.match(read(`netlify/functions/${f}.mjs`), /config = \{ path: '\/api\/\w+/);
  for (const f of ['ai', 'transcribe', 'google']) assert.match(read(`netlify/lib/${f}.js`), /requireUser/);
});
test('.env.example lists every variable the server reads, with no values', () => {
  const ex = read('.env.example'); const names = [...ex.matchAll(/^([A-Z_]+)=(.*)$/gm)];
  const used = new Set(walk(path.join(root, 'netlify')).flatMap((f) => [...readFileSync(f, 'utf8').matchAll(/env\.([A-Z_]{4,})/g)].map((m) => m[1])));
  used.delete('URL');
  for (const u of used) assert.ok(names.some((n) => n[1] === u), `${u} missing from .env.example`);
  for (const [, n, v] of names) if (!/^(AI_MODEL|TRANSCRIBE_MODEL)$/.test(n)) assert.equal(v, '', `${n} must be empty in the example`);
});
test('no secrets or tracking in the source tree', () => {
  for (const f of walk(root)) {
    if (/\.(png|jpg|ico)$/.test(f) || f.endsWith('.env.example') || f.includes('/tests/')) continue;
    const text = readFileSync(f, 'utf8');
    assert.equal(/sk-ant-[A-Za-z0-9]{10,}|gsk_[A-Za-z0-9]{10,}|eyJhbGciOi[A-Za-z0-9_-]{20,}|GOCSPX-[A-Za-z0-9_-]{10,}/.test(text), false, `secret-looking value in ${f}`);
    if (/\.(js|mjs|html)$/.test(f) && !f.includes('/tests/')) assert.equal(/google-analytics|gtag\(|googletagmanager|hotjar|facebook\.net|sentry|mixpanel/i.test(text), false, `tracker in ${f}`);
  }
});
test('browser code never references server-only secret names', () => {
  for (const f of walk(path.join(root, 'src')).concat(walk(path.join(root, 'public')))) {
    assert.equal(/SERVICE_ROLE|ANTHROPIC_API_KEY|GROQ_API_KEY|CLIENT_SECRET|TOKEN_ENC_KEY/.test(readFileSync(f, 'utf8')), false, f);
  }
});
test('build: writes only public settings, verifies clean, and refuses a secret key', () => {
  const out = mkdtempSync(path.join(tmpdir(), 'dist-'));
  build({ env: { SUPABASE_URL: 'https://abc.supabase.co', SUPABASE_ANON_KEY: 'anon-public', ANTHROPIC_API_KEY: 'sk-ant-SHOULDNOTLEAK123' }, out, log: quiet });
  const cfg = readFileSync(path.join(out, 'src/config.js'), 'utf8');
  assert.match(cfg, /abc\.supabase\.co/); assert.equal(cfg.includes('SHOULDNOTLEAK'), false);
  assert.deepEqual(verifyDist(out, { ANTHROPIC_API_KEY: 'sk-ant-SHOULDNOTLEAK123' }), []);
  const jwt = (role) => `h.${Buffer.from(JSON.stringify({ role })).toString('base64url')}.s`;
  assert.equal(looksSecret(jwt('service_role')), true); assert.equal(looksSecret(jwt('anon')), false); assert.equal(looksSecret('sb_secret_abc'), true);
  assert.throws(() => build({ env: { SUPABASE_URL: 'https://abc.supabase.co', SUPABASE_ANON_KEY: jwt('service_role') }, out, log: quiet }), /SECRET/);
  assert.throws(() => build({ env: { SUPABASE_URL: 'http://evil.example', SUPABASE_ANON_KEY: 'a' }, out, log: quiet }), /supabase\.co/);
});
test('verify-dist catches leaks and missing imports', () => {
  const out = mkdtempSync(path.join(tmpdir(), 'dist-')); build({ env: {}, out, log: quiet });
  writeFileSync(path.join(out, 'src/leak.js'), "import './nope.js'; const k = 'GROQ_API_KEY';");
  const p = verifyDist(out, {}); assert.ok(p.some((x) => /GROQ_API_KEY/.test(x))); assert.ok(p.some((x) => /nope\.js/.test(x)));
});
test('build without settings still works and signals sign-in is off', () => {
  const out = mkdtempSync(path.join(tmpdir(), 'dist-')); const logs = [];
  build({ env: {}, out, log: (m) => logs.push(m) });
  assert.ok(logs.some((l) => /not set/.test(l))); assert.ok(existsSync(path.join(out, 'index.html')));
});
test('personal note: title is fixed, placeholder is never displayed as the message', () => {
  assert.equal(NOTE_TITLE, 'A Little Note from Your Bibish ❤️');
  const raw = read('content/bibish-note.txt');
  assert.equal(parseNote(raw).ready, !raw.includes('@@PLACEHOLDER@@'));
  assert.deepEqual(parseNote('@@PLACEHOLDER@@ blah'), { ready: false, paragraphs: [] });
  assert.deepEqual(parseNote(''), { ready: false, paragraphs: [] });
  assert.deepEqual(parseNote('One\r\nstill one\n\n\nTwo ❤️\n').paragraphs, ['One\nstill one', 'Two ❤️']);
});

test('the real message is in place, complete, and renders without the title repeated', () => {
  const raw = read('content/bibish-note.txt');
  assert.equal(raw.includes('@@PLACEHOLDER@@'), false);
  const n = parseNote(raw);
  assert.equal(n.ready, true);
  assert.deepEqual(n.paragraphs, [
    'And please, remember…',
    'I no be gari girl, oh! 😂',
    'And you no be gari man, oh! 🤭❤️',
    "Now go and conquer your day, Mr. Rawlings. Work smart, take your rest, and don't forget to smile. Somebody's stubborn Bibish is rooting for you. ❤️",
  ]);
  assert.equal(raw.split('\n')[0], 'A Little Note from Your Bibish ❤️');
});
