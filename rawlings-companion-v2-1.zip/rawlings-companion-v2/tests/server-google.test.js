import test from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { createGoogleHandler, buildRawEmail, sanitizeCell } from '../netlify/lib/google.js';
import { encrypt, decrypt, signState, verifyState } from '../netlify/lib/crypto.js';
import { fakeFetch, resp, authOk, req, baseEnv } from './helpers.js';

const KEY = randomBytes(32).toString('base64');
const env = { ...baseEnv, SUPABASE_SERVICE_ROLE_KEY: 'svc', GOOGLE_CLIENT_ID: 'cid', GOOGLE_CLIENT_SECRET: 'sec', TOKEN_ENC_KEY: KEY, SITE_URL: 'https://site.test' };
const tokenRow = [(u) => u.includes('/rest/v1/google_tokens') && !u.includes('DELETE'), () => resp(200, [{ refresh_token: encrypt('RT', KEY), scopes: 's', google_email: 'g@x.com' }])];
const h = (deps) => createGoogleHandler(deps);

test('crypto: round trip, tamper detection, state expiry', () => {
  assert.equal(decrypt(encrypt('secret', KEY), KEY), 'secret');
  const t = encrypt('secret', KEY); assert.throws(() => decrypt(t.slice(0, -2) + 'AA', KEY));
  const s = signState({ uid: 'u', exp: 1000 }, KEY);
  assert.equal(verifyState(s, KEY, 500).uid, 'u');
  assert.equal(verifyState(s, KEY, 2000), null, 'expired');
  assert.equal(verifyState(s.slice(0, -2) + 'xx', KEY, 500), null, 'tampered');
  assert.equal(verifyState('garbage', KEY, 500), null);
});
test('missing Google configuration is listed, not hidden', async () => {
  const r = await h({ env: baseEnv, fetch: fakeFetch([]) })(req('/api/google/status', { method: 'GET' }));
  assert.equal(r.status, 503); assert.match((await r.json()).message, /GOOGLE_CLIENT_ID/);
});
test('requires sign-in', async () => {
  const r = await h({ env, fetch: fakeFetch([]) })(new Request('https://site.test/api/google/status'));
  assert.equal(r.status, 401);
});
test('start: returns a Google consent URL with signed state and offline access', async () => {
  const r = await h({ env, fetch: fakeFetch([authOk]) })(req('/api/google/start'));
  const { url } = await r.json(); const u = new URL(url);
  assert.equal(u.host, 'accounts.google.com'); assert.equal(u.searchParams.get('access_type'), 'offline');
  assert.ok(verifyState(u.searchParams.get('state'), KEY));
  assert.equal(u.searchParams.get('redirect_uri'), 'https://site.test/api/google/callback');
});
test('callback rejects forged or missing state without calling Google', async () => {
  const f = fakeFetch([]);
  const r = await h({ env, fetch: f })(new Request('https://site.test/api/google/callback?code=c&state=forged'));
  assert.equal(r.status, 302); assert.match(r.headers.get('location'), /error=bad_state/); assert.equal(f.calls.length, 0);
  const denied = await h({ env, fetch: f })(new Request('https://site.test/api/google/callback?error=access_denied'));
  assert.match(denied.headers.get('location'), /error=denied/);
});
test('callback stores the refresh token encrypted, never in plain text', async () => {
  const state = signState({ uid: 'u1', exp: Date.now() + 60000 }, KEY);
  let saved;
  const f = fakeFetch([
    [(u) => u.includes('oauth2.googleapis.com/token'), () => resp(200, { access_token: 'AT', refresh_token: 'PLAIN_RT', scope: 'x', id_token: 'a.' + Buffer.from('{"email":"g@x.com"}').toString('base64url') + '.c' })],
    [(u) => u.includes('/rest/v1/google_tokens'), (u, init) => { saved = init.body; return resp(201, {}); }],
  ]);
  const r = await h({ env, fetch: f })(new Request(`https://site.test/api/google/callback?code=c&state=${encodeURIComponent(state)}`));
  assert.match(r.headers.get('location'), /connected=1/);
  assert.equal(saved.includes('PLAIN_RT'), false);
  assert.equal(decrypt(JSON.parse(saved).refresh_token, KEY), 'PLAIN_RT');
});
test('changes need explicit confirmation (calendar, sheets, gmail draft)', async () => {
  for (const [path, body] of [['/api/google/calendar/events', { summary: 'x', start: '2026-11-01T10:00:00Z', end: '2026-11-01T11:00:00Z' }], ['/api/google/sheets/export', { sheets: [{ name: 'a', rows: [['x']] }] }], ['/api/google/gmail/draft', { to: 'a@b.co', subject: 's', body: 'b' }]]) {
    const f = fakeFetch([authOk, tokenRow]);
    const r = await h({ env, fetch: f })(req(path, { body: JSON.stringify(body), headers: { 'content-type': 'application/json' } }));
    assert.equal(r.status, 400); assert.equal((await r.json()).error, 'confirmation_required');
    assert.equal(f.calls.some((c) => c.url.includes('googleapis.com/calendar') || c.url.includes('sheets.googleapis') || c.url.includes('gmail.googleapis')), false);
  }
});
test('confirmed calendar event is created after validation; bad times rejected', async () => {
  const f = fakeFetch([authOk, tokenRow,
    [(u) => u.includes('oauth2.googleapis.com/token'), () => resp(200, { access_token: 'AT', expires_in: 3600 })],
    [(u) => u.includes('googleapis.com/calendar'), () => resp(200, { id: 'e1', htmlLink: 'https://cal/e1' })]]);
  const mk = (b) => h({ env, fetch: f })(req('/api/google/calendar/events', { body: JSON.stringify({ confirm: true, ...b }), headers: { 'content-type': 'application/json' } }));
  assert.equal((await mk({ summary: 'x', start: '2026-11-01T11:00:00Z', end: '2026-11-01T10:00:00Z' })).status, 400);
  assert.equal((await mk({ summary: '', start: '2026-11-01T10:00:00Z', end: '2026-11-01T11:00:00Z' })).status, 400);
  const ok = await mk({ summary: 'Board', start: '2026-11-01T10:00:00Z', end: '2026-11-01T11:00:00Z' });
  assert.equal(ok.status, 200);
});
test('gmail: only drafts are ever created; no send endpoint exists', async () => {
  const f = fakeFetch([authOk, tokenRow]);
  const r = await h({ env, fetch: f })(req('/api/google/gmail/send', { body: JSON.stringify({ confirm: true }), headers: { 'content-type': 'application/json' } }));
  assert.equal(r.status, 404);
  const src = await import('node:fs').then((fs) => fs.readFileSync(new URL('../netlify/lib/google.js', import.meta.url), 'utf8'));
  assert.equal(/messages\/send|drafts\/send/.test(src), false);
  assert.equal(/gmail\.send|gmail\.modify|gmail\.readonly/.test(src), false);
});
test('email and spreadsheet sanitising', () => {
  assert.equal(buildRawEmail({ to: 'a@b.co', subject: 'Hi\r\nBcc: evil@x.com', body: 'x' }).includes('Bcc: evil'), false);
  assert.match(sanitizeCell('=HYPERLINK("http://x")'), /^'/, 'formula injection neutralised');
  assert.equal(sanitizeCell('plain'), 'plain');
});

test("sheet names containing an apostrophe are escaped in the range", async () => {
  let ranges;
  const f = fakeFetch([authOk, tokenRow,
    [(u) => u.includes('oauth2.googleapis.com/token'), () => resp(200, { access_token: 'AT' })],
    [(u) => u.endsWith('/v4/spreadsheets'), () => resp(200, { spreadsheetId: 'S1' })],
    [(u) => u.includes('values:batchUpdate'), (u, init) => { ranges = JSON.parse(init.body).data.map((d) => d.range); return resp(200, {}); }]]);
  const r = await h({ env, fetch: f })(req('/api/google/sheets/export', { body: JSON.stringify({ confirm: true, sheets: [{ name: "Bob's tasks", rows: [['a']] }] }), headers: { 'content-type': 'application/json' } }));
  assert.equal(r.status, 200); assert.deepEqual(ranges, ["'Bob''s tasks'!A1"]);
});
