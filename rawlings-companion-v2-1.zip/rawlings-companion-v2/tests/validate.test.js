import test from 'node:test';
import assert from 'node:assert/strict';
import { validateEmail, validatePassword, validateFile, FILE_LIMITS, toBase64, looksBinary } from '../src/lib/validate.js';

test('email validation', () => {
  assert.equal(validateEmail('a@b.co'), null);
  for (const bad of ['', 'nope', 'a@b', 'a b@c.com', 'x'.repeat(260) + '@a.com']) assert.ok(validateEmail(bad), bad);
});
test('password validation', () => {
  assert.equal(validatePassword('correct horse battery', 'correct horse battery'), null);
  assert.match(validatePassword('short1'), /10/);
  assert.match(validatePassword('aaaaaaaaaaaa'), /simple/);
  assert.match(validatePassword('a'.repeat(73)), /72/);
  assert.match(validatePassword('longenoughpw', 'different'), /match/);
});
test('upload validation: supported files accepted', () => {
  assert.deepEqual(validateFile({ name: 'a.txt', size: 10, type: 'text/plain' }).kind, 'text');
  assert.equal(validateFile({ name: 'r.PDF', size: 1000, type: 'application/pdf' }).kind, 'pdf');
  assert.equal(validateFile({ name: 'p.jpg', size: 1000, type: 'image/jpeg' }).mediaType, 'image/jpeg');
  assert.equal(validateFile({ name: 'a.csv', size: 10, type: '' }).ok, true); // some browsers give no type
});
test('upload validation: errors are specific', () => {
  assert.match(validateFile(null).error, /No file/);
  assert.match(validateFile({ name: 'a.txt', size: 0, type: 'text/plain' }).error, /empty/);
  assert.match(validateFile({ name: 'a.docx', size: 10, type: '' }).error, /PDF/);
  assert.match(validateFile({ name: 'a.exe', size: 10, type: '' }).error, /not supported/);
  assert.match(validateFile({ name: 'noext', size: 10, type: '' }).error, /not supported/);
  assert.match(validateFile({ name: 'a.txt', size: FILE_LIMITS.textBytes + 1, type: 'text/plain' }).error, /too large/);
  assert.match(validateFile({ name: 'a.pdf', size: FILE_LIMITS.binaryBytes + 1, type: 'application/pdf' }).error, /too large/);
  assert.match(validateFile({ name: 'a.png', size: 10, type: 'application/pdf' }).error, /does not match/);
});
test('binary detection and base64', () => {
  assert.equal(looksBinary('a\u0000b'), true);
  assert.equal(looksBinary('plain'), false);
  assert.equal(toBase64(new TextEncoder().encode('hi').buffer), 'aGk=');
});
