// Shared test helpers: fake fetch router and request builders.
export const USER = { id: '11111111-1111-1111-1111-111111111111', email: 'a@example.com' };
export const baseEnv = { SUPABASE_URL: 'https://abc.supabase.co', SUPABASE_ANON_KEY: 'anon-public' };

/** routes: array of [predicate(url, init), responder(url, init)]. Records every call in .calls */
export function fakeFetch(routes) {
  const calls = [];
  const f = async (url, init = {}) => {
    calls.push({ url: String(url), init });
    for (const [match, respond] of routes) if (match(String(url), init)) return respond(String(url), init);
    throw new Error(`unexpected fetch ${url}`);
  };
  f.calls = calls;
  return f;
}
export const resp = (status, body) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });
export const authOk = [(u) => u.endsWith('/auth/v1/user'), () => resp(200, USER)];
export const req = (path, { method = 'POST', headers = {}, body } = {}) =>
  new Request(`https://site.test${path}`, { method, headers: { authorization: 'Bearer tok', ...headers }, body });
export const memStorage = () => { const m = new Map(); return { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, v), removeItem: (k) => m.delete(k) }; };
