import test from 'node:test';
import assert from 'node:assert/strict';
import { createTranscribeHandler, AUDIO_LIMITS } from '../netlify/lib/transcribe.js';
import { fakeFetch, resp, authOk, req, baseEnv } from './helpers.js';

const env = { ...baseEnv, GROQ_API_KEY: 'gsk-test' };
const groq = (respond) => [(u) => u.startsWith('https://api.groq.com'), respond];
const call = (deps, { type = 'audio/webm', body = new Uint8Array([1, 2, 3]), qs = '' } = {}) =>
  createTranscribeHandler(deps)(req(`/api/transcribe${qs}`, { body, headers: { 'content-type': type } }));

test('requires sign-in and configuration', async () => {
  const noAuth = await createTranscribeHandler({ env, fetch: fakeFetch([]) })(new Request('https://s.test/api/transcribe', { method: 'POST', body: 'x' }));
  assert.equal(noAuth.status, 401);
  const noKey = await call({ env: baseEnv, fetch: fakeFetch([authOk]) });
  assert.equal(noKey.status, 503); assert.equal((await noKey.json()).error, 'transcription_not_configured');
});
test('successful transcription returns the text', async () => {
  const f = fakeFetch([authOk, groq((u, init) => { assert.equal(init.headers.authorization, 'Bearer gsk-test'); assert.ok(init.body instanceof FormData); assert.equal(init.body.get('model'), 'whisper-large-v3-turbo'); return resp(200, { text: ' Hello team ' }); })]);
  const r = await call({ env, fetch: f }, { qs: '?language=en' });
  assert.deepEqual(await r.json(), { text: 'Hello team' });
});
test('silence is reported, not turned into fake text', async () => {
  const r = await call({ env, fetch: fakeFetch([authOk, groq(() => resp(200, { text: '  ' }))]) });
  const b = await r.json(); assert.equal(b.empty, true); assert.equal(b.text, '');
});
test('input validation: type, empty, too large', async () => {
  const f = fakeFetch([authOk]);
  assert.equal((await call({ env, fetch: f }, { type: 'application/pdf' })).status, 415);
  assert.equal((await call({ env, fetch: f }, { body: new Uint8Array() })).status, 400);
  const big = await createTranscribeHandler({ env, fetch: f })(req('/api/transcribe', { body: 'x', headers: { 'content-type': 'audio/webm', 'content-length': String(AUDIO_LIMITS.maxBytes + 1) } }));
  assert.equal(big.status, 413);
});
test('provider errors are surfaced honestly', async () => {
  const run = async (respond) => { const r = await call({ env, fetch: fakeFetch([authOk, groq(respond)]) }); return [r.status, (await r.json()).error]; };
  assert.deepEqual(await run(() => resp(401, {})), [502, 'transcription_key_rejected']);
  assert.deepEqual(await run(() => resp(429, {})), [502, 'transcription_rate_limited']);
  assert.deepEqual(await run(() => resp(500, {})), [502, 'transcription_provider_error']);
  assert.deepEqual(await run(() => resp(200, { nottext: 1 })), [502, 'transcription_bad_response']);
  assert.deepEqual(await run(() => { throw new Error('dns'); }), [502, 'transcription_unreachable']);
  assert.deepEqual(await run(() => { const e = new Error('t'); e.name = 'AbortError'; throw e; }), [504, 'transcription_timeout']);
});
