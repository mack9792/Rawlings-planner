-- Extra checks (storage folders, incident/project ownership, anon blocked, constraint limits). Rolled back.
begin;
do $$
declare a uuid := gen_random_uuid(); b uuid := gen_random_uuid(); pa uuid; n int;
begin
  insert into auth.users (id, email) values (a,'a@x.invalid'),(b,'b@x.invalid');
  perform set_config('request.jwt.claim.sub', a::text, true); set local role authenticated;
  insert into public.projects (title) values ('P-A') returning id into pa;
  insert into storage.objects (bucket_id, name) values ('private-files', a::text || '/ok.txt');
  begin insert into storage.objects (bucket_id, name) values ('private-files', b::text || '/steal.txt'); raise exception 'FAIL: wrote into other user folder';
  exception when insufficient_privilege or check_violation then null; end;
  begin insert into public.tasks (title) values (repeat('x', 5000)); raise exception 'FAIL: oversize title accepted';
  exception when check_violation then null; end;
  reset role;
  perform set_config('request.jwt.claim.sub', b::text, true); set local role authenticated;
  select count(*) into n from storage.objects; if n <> 0 then raise exception 'FAIL: B sees A files'; end if;
  begin insert into public.incidents (title, project_id) values ('x', pa); raise exception 'FAIL: incident linked to other user project';
  exception when raise_exception then if sqlerrm like 'FAIL%' then raise; end if; end;
  reset role;
end $$;
select 'Success: extra checks passed';
rollback;
