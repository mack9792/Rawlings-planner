import test from 'node:test';
import assert from 'node:assert/strict';
import { VoiceRecorder, recordingSupported, pickMimeType, describeMicError, fmtClock } from '../src/lib/recorder.js';

function fakeEnv({ denyWith, chunks = [new Blob(['abc'])], supported = ['audio/webm'] } = {}) {
  const track = { stopped: false, stop() { this.stopped = true; } };
  const stream = { getTracks: () => [track] };
  class MR {
    static isTypeSupported(t) { return supported.includes(t); }
    constructor(s, o) { this.mimeType = o.mimeType || ''; this.state = 'inactive'; }
    start() { this.state = 'recording'; chunks.forEach((c) => this.ondataavailable({ data: c })); }
    stop() { this.state = 'inactive'; setTimeout(() => this.onstop && this.onstop(), 0); }
  }
  return { track, env: { navigator: { mediaDevices: { getUserMedia: async () => { if (denyWith) { const e = new Error('x'); e.name = denyWith; throw e; } return stream; } } }, MediaRecorder: MR } };
}

test('support detection', () => {
  assert.equal(recordingSupported({}), false);
  assert.equal(recordingSupported(fakeEnv().env), true);
  assert.equal(pickMimeType(undefined), '');
  assert.equal(pickMimeType(fakeEnv({ supported: ['audio/mp4'] }).env.MediaRecorder), 'audio/mp4');
});
test('record, stop, returns a blob and releases the microphone', async () => {
  const { env, track } = fakeEnv();
  const r = new VoiceRecorder({ env });
  await r.start();
  assert.equal(r.state, 'recording');
  const [a, b] = [r.stop(), r.stop()];
  assert.equal(a, b, 'stop is idempotent');
  const out = await a;
  assert.ok(out.blob.size > 0);
  assert.equal(out.mimeType, 'audio/webm');
  assert.equal(track.stopped, true);
});
test('discard (cancel) releases the microphone and resets', async () => {
  const { env, track } = fakeEnv();
  const r = new VoiceRecorder({ env });
  await r.start(); r.cancel();
  assert.equal(r.state, 'idle'); assert.equal(track.stopped, true);
});
test('empty recording is reported, not faked', async () => {
  const r = new VoiceRecorder({ env: fakeEnv({ chunks: [] }).env });
  await r.start();
  await assert.rejects(r.stop(), /Nothing was recorded/);
});
test('microphone errors are explained', async () => {
  await assert.rejects(new VoiceRecorder({ env: fakeEnv({ denyWith: 'NotAllowedError' }).env }).start(), /permission was denied/);
  await assert.rejects(new VoiceRecorder({ env: fakeEnv({ denyWith: 'NotFoundError' }).env }).start(), /No microphone/);
  await assert.rejects(new VoiceRecorder({ env: {} }).start(), /cannot record/);
  assert.match(describeMicError({ name: 'SecurityError' }), /https/);
  assert.match(describeMicError({ name: 'Weird', message: 'boom' }), /boom/);
});
test('clock format', () => { assert.equal(fmtClock(75), '1:15'); assert.equal(fmtClock(5), '0:05'); });
