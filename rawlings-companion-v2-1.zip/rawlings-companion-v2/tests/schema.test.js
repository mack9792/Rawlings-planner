// Static checks on the SQL (always run) + a live run against a local Postgres when TEST_PG_URL is set.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';

const sql = readFileSync(new URL('../supabase/schema.sql', import.meta.url), 'utf8');
const tables = [...sql.matchAll(/create table if not exists public\.(\w+)/g)].map((m) => m[1]);

test('every table has a user_id owner or is google_tokens', () => {
  assert.ok(tables.length >= 10);
  for (const t of tables) {
    const block = sql.split(`create table if not exists public.${t}`)[1].split(');')[0];
    assert.match(block, /user_id\s+uuid[^,]*references auth\.users/, t);
  }
});
test('RLS is enabled with an own-rows policy for every user table; anon has no access', () => {
  const list = sql.match(/foreach t in array array\[([\s\S]*?)\]/)[1];
  const covered = [...list.matchAll(/'(\w+)'/g)].map((m) => m[1]);
  assert.deepEqual(covered.sort(), tables.filter((t) => t !== 'google_tokens').sort());
  assert.match(sql, /enable row level security/);
  assert.match(sql, /revoke all on public\.%I from anon/);
  assert.match(sql, /using \(user_id = \(select auth\.uid\(\)\)\)/);
  assert.match(sql, /with check \(user_id = \(select auth\.uid\(\)\)\)/);
});
test('google_tokens is unreachable from client roles', () => {
  assert.match(sql, /alter table public\.google_tokens enable row level security/);
  assert.match(sql, /revoke all on public\.google_tokens from anon, authenticated/);
  assert.equal(/create policy[^;]*google_tokens/.test(sql), false);
});
test('file bucket is private with per-user folders', () => {
  assert.match(sql, /'private-files', 'private-files', false/);
  assert.equal((sql.match(/storage\.foldername\(name\)\)\[1\] = \(select auth\.uid\(\)\)::text/g) || []).length >= 4, true);
});
test('no hidden admin access: no security definer, no hardcoded emails/ids, no service-role policies', () => {
  assert.equal(/security definer/i.test(sql), false);
  assert.equal(/@[a-z0-9-]+\.[a-z]{2,}/i.test(sql.replace(/--.*$/gm, '')), false);
  assert.equal(/to service_role|to postgres|using \(true\)|with check \(true\)/i.test(sql), false);
});

const url = process.env.TEST_PG_URL;
test('LIVE (local Postgres): schema applies twice and isolation checks pass', { skip: !url && 'set TEST_PG_URL to a scratch Postgres that has tests/db/supabase_stub.sql loaded' }, () => {
  const run = (f) => spawnSync('psql', [url, '-v', 'ON_ERROR_STOP=1', '-q', '-t', '-A', '-f', new URL(f, import.meta.url).pathname], { encoding: 'utf8' });
  for (const f of ['../supabase/schema.sql', '../supabase/schema.sql']) { const r = run(f); assert.equal(r.status, 0, r.stderr); }
  for (const f of ['../supabase/rls_isolation_check.sql', './db/extra_checks.sql']) { const r = run(f); assert.equal(r.status, 0, r.stderr); assert.match(r.stdout, /Success/); }
});
