// Browser smoke test (optional; needs Playwright + Chromium). Run: npm run build && node tests/e2e/smoke.mjs
// Uses a FAKE in-memory Supabase/AI backend via request interception: it proves the UI flows work,
// NOT that a real Supabase/AI/Google account works.
import { createRequire } from 'node:module';
import { execSync, spawn } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PLAYWRIGHT_PATH || path.join(execSync('npm root -g').toString().trim(), 'playwright'));
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');

const results = []; const check = (name, ok, extra = '') => { results.push([name, ok]); console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${ok ? '' : '  ' + extra}`); };
const PORT = 4199;
const buildWith = (env) => execSync('node scripts/build.mjs', { cwd: root, env: { ...process.env, ...env }, stdio: 'ignore' });
const serve = () => spawn('node', ['scripts/serve.mjs'], { cwd: root, env: { ...process.env, PORT: String(PORT) }, stdio: 'ignore' });
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const SB = 'https://fake.supabase.co';

async function newPage(browser, { backend = true } = {}) {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 800 }, permissions: ['microphone'] });
  const page = await ctx.newPage();
  const errors = []; page.on('pageerror', (e) => errors.push(e.message)); page.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errors.push(m.text()); });
  const db = { tasks: [], projects: [], notes: [], meetings: [], decisions: [], incidents: [], ai_history: [], voice_notes: [], uploaded_files: [] };
  const log = { api: [] };
  if (backend) {
    await ctx.route(`${SB}/**`, async (route) => {
      const u = new URL(route.request().url()); const m = route.request().method();
      const j = (s, b) => route.fulfill({ status: s, contentType: 'application/json', body: JSON.stringify(b) });
      if (u.pathname === '/auth/v1/token') { const b = JSON.parse(route.request().postData() || '{}'); return b.password === 'correct-password-1' ? j(200, { access_token: 'AT', refresh_token: 'RT', expires_in: 3600, user: { id: 'u1', email: 'rawlings@example.com' } }) : j(400, { error_code: 'invalid_credentials', msg: 'Invalid login credentials' }); }
      if (u.pathname === '/auth/v1/recover') return j(200, {});
      if (u.pathname === '/auth/v1/logout') return route.fulfill({ status: 204 });
      const t = u.pathname.split('/').pop();
      if (u.pathname.startsWith('/rest/v1/') && db[t]) {
        if (m === 'GET') return j(200, db[t]);
        if (m === 'POST') { const row = { id: `${t}-${db[t].length + 1}`, created_at: new Date().toISOString(), done: false, progress: 0, ...JSON.parse(route.request().postData()) }; db[t].push(row); return j(201, [row]); }
        if (m === 'DELETE') { db[t].length = 0; return route.fulfill({ status: 204 }); }
        if (m === 'PATCH') return j(200, db[t].slice(0, 1));
      }
      return j(404, { code: 'PGRST205' });
    });
    await ctx.route('**/api/**', async (route) => {
      const u = new URL(route.request().url()); log.api.push(`${route.request().method()} ${u.pathname}`);
      const j = (s, b) => route.fulfill({ status: s, contentType: 'application/json', body: JSON.stringify(b) });
      if (u.pathname === '/api/transcribe') return j(200, { text: 'Remind me to renew the firewall licence on Friday' });
      if (u.pathname === '/api/ai') { const b = JSON.parse(route.request().postData()); return b.task === 'actions' ? j(200, { text: '{}', items: [{ title: 'Renew firewall licence', owner: null, due: 'Friday', priority: 'High' }] }) : j(200, { text: 'FAKE AI ANSWER <b>not markup</b>' }); }
      if (u.pathname === '/api/google/status') return j(503, { error: 'google_not_configured', message: 'Google is not set up yet. Missing server settings: GOOGLE_CLIENT_ID.' });
      return j(404, { error: 'nf', message: 'nf' });
    });
  }
  return { page, errors, db, log, ctx };
}

(async () => {
  let server;
  const browser = await chromium.launch({ args: ['--use-fake-device-for-media-stream', '--use-fake-ui-for-media-stream'] });
  try {
    // 1) Not configured
    buildWith({ SUPABASE_URL: '', SUPABASE_ANON_KEY: '' }); server = serve(); await wait(800);
    let { page, errors } = await newPage(browser, { backend: false });
    await page.goto(`http://localhost:${PORT}/`); await page.waitForSelector('.auth-card');
    check('unconfigured build says sign-in is off (no fake login)', (await page.textContent('.auth-card')).includes('not connected to a database'));
    check('no JS errors when unconfigured', errors.length === 0, errors.join('|'));
    server.kill(); await wait(300);

    // 2) Configured with a fake backend
    buildWith({ SUPABASE_URL: SB, SUPABASE_ANON_KEY: 'anon-public' }); server = serve(); await wait(800);
    let ctxo = await newPage(browser); page = ctxo.page; errors = ctxo.errors;
    await page.goto(`http://localhost:${PORT}/`); await page.waitForSelector('form');
    await page.fill('input[type=email]', 'rawlings@example.com'); await page.fill('input[type=password]', 'wrong-password-x');
    await page.click('button[type=submit]'); await page.waitForSelector('.auth-msg .error');
    check('wrong password shows a friendly error', (await page.textContent('.auth-msg')).includes('Incorrect email or password'));
    await page.fill('input[type=password]', 'correct-password-1'); await page.click('button[type=submit]');
    await page.waitForSelector('.page-title');
    check('sign in shows the dashboard', (await page.textContent('.page-title')).match(/Good (morning|afternoon|evening)/) !== null);
    check('mobile: no horizontal overflow', await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1));

    // quick add task and see it on the dashboard
    await page.getByRole('button', { name: /add/i }).first().click().catch(() => {});
    const titleInput = page.locator('input[maxlength="240"]').first();
    if (await titleInput.count()) { await titleInput.fill('Renew SSL certificates'); await page.locator('form').filter({ has: titleInput }).locator('button[type=submit]').click(); await wait(500); }
    check('task creation sent to database (RLS-protected REST)', ctxo.db.tasks.some((t) => t.title === 'Renew SSL certificates'));

    // every route renders without JS errors
    for (const r of ['projects', 'incidents', 'ai', 'voice', 'files', 'records', 'google', 'help', 'note']) { await page.goto(`http://localhost:${PORT}/#/${r}`); await wait(350); }
    check('all pages render without JS errors', errors.length === 0, errors.join('|'));
    const stray = [];
    for (const r of ['dashboard', 'projects', 'incidents', 'ai', 'voice', 'files', 'records', 'google', 'help', 'note']) {
      await page.goto(`http://localhost:${PORT}/#/${r}`); await wait(350);
      const t = await page.evaluate(() => document.querySelector('#content').innerText);
      if (/(^|\s)(null|undefined|NaN|\[object Object\])(\s|$)/.test(t)) stray.push(r);
    }
    check('no stray "null"/"undefined"/"[object Object]" text on any page', stray.length === 0, stray.join(','));

    // note page: placeholder must not be shown as the message
    await page.goto(`http://localhost:${PORT}/#/note`); await wait(400);
    const noteTxt = await page.textContent('.note-card');
    check('note page shows fixed title', noteTxt.includes('A Little Note from Your Bibish ❤️'));
    check('note page never displays the missing-message placeholder', !noteTxt.includes('@@PLACEHOLDER@@') && !noteTxt.includes('has not been added'));
    for (const line of ['And please, remember…', 'I no be gari girl, oh! 😂', 'And you no be gari man, oh! 🤭❤️', "Now go and conquer your day, Mr. Rawlings. Work smart, take your rest, and don't forget to smile. Somebody's stubborn Bibish is rooting for you. ❤️"]) check(`note shows: ${line.slice(0, 30)}…`, noteTxt.includes(line));
    check('title appears once (not duplicated)', noteTxt.split('A Little Note from Your Bibish').length === 2);
    for (const [w, h] of [[360, 780], [1280, 800]]) {
      await page.setViewportSize({ width: w, height: h }); await wait(200);
      check(`note fits ${w}px wide without sideways scrolling`, await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1));
      await page.screenshot({ path: path.join(root, `tests/e2e/note-${w}.png`), fullPage: true });
    }
    await page.setViewportSize({ width: 390, height: 800 });
    await page.screenshot({ path: path.join(root, 'tests/e2e/note.png') });

    // AI: output is plain text, never markup
    await page.goto(`http://localhost:${PORT}/#/ai`); await wait(300);
    await page.fill('textarea >> nth=0', 'Draft a status update'); await page.click('button[type=submit]'); await page.waitForSelector('.answer');
    check('AI answer displayed as text (no HTML injection)', (await page.textContent('.answer')).includes('<b>not markup</b>') && (await page.locator('.answer b').count()) === 0);

    // Voice: real (fake-device) recording, stop, playback, transcribe, edit
    await page.goto(`http://localhost:${PORT}/#/voice`); await wait(300);
    await page.getByRole('button', { name: /Start recording/ }).click(); await wait(1800);
    check('recording is in progress (timer runs, Stop shown)', await page.getByRole('button', { name: /Stop/ }).isVisible());
    await page.getByRole('button', { name: /Stop/ }).click(); await page.waitForSelector('audio');
    check('playback element appears with recorded audio', await page.evaluate(() => { const a = document.querySelector('audio'); return !!a && a.src.startsWith('blob:'); }));
    await page.getByRole('button', { name: /Transcribe/ }).click(); await page.waitForSelector('textarea');
    check('transcript is shown in an editable box', (await page.locator('textarea').first().inputValue()).includes('firewall licence'));
    await page.screenshot({ path: path.join(root, 'tests/e2e/voice.png') });

    // Files: unsupported type is rejected client-side with a clear message and no server call
    await page.goto(`http://localhost:${PORT}/#/files`); await wait(300);
    const before = ctxo.log.api.length;
    await page.setInputFiles('input[type=file]', { name: 'budget.xlsx', mimeType: 'application/vnd.ms-excel', buffer: Buffer.from('x') });
    await wait(300);
    check('unsupported upload rejected with a clear message', (await page.textContent('#content')).includes('not supported'));
    check('rejected upload never reached the AI', ctxo.log.api.length === before);
    await page.setInputFiles('input[type=file]', { name: 'notes.txt', mimeType: 'text/plain', buffer: Buffer.from('Action: renew firewall licence by Friday') });
    await wait(300);
    await page.getByRole('button', { name: /Extract action items/ }).click(); await page.waitForSelector('.actions');
    check('file action items extracted and offered', (await page.textContent('.actions')).includes('Renew firewall licence'));

    // Google not configured -> honest message
    await page.goto(`http://localhost:${PORT}/#/google`); await wait(600);
    check('Google page reports missing setup honestly', (await page.textContent('#content')).includes('not set up'));
    check('no JS errors across the whole session', errors.length === 0, errors.join('|'));

    // Password recovery link opens the reset form
    const p2 = await newPage(browser); await p2.page.goto(`http://localhost:${PORT}/#access_token=RECOV&type=recovery&expires_in=3600`);
    await p2.page.waitForSelector('.auth-card');
    check('recovery link shows set-new-password form', (await p2.page.textContent('.auth-card')).includes('Choose a new password'));
  } catch (e) { check('smoke run completed', false, e.stack); }
  finally { await browser.close(); if (server) server.kill(); }
  const failed = results.filter(([, ok]) => !ok).length;
  console.log(`\n${results.length - failed}/${results.length} browser checks passed`);
  process.exit(failed ? 1 : 0);
})();
