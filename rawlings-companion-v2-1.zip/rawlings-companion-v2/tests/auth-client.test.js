import test from 'node:test';
import assert from 'node:assert/strict';
import { createClient } from '../src/lib/supabase.js';
import { callApi } from '../src/lib/api.js';
import { parseRecoveryHash } from '../src/lib/recovery.js';
import { fakeFetch, resp, memStorage } from './helpers.js';

const cfg = { url: 'https://abc.supabase.co', anonKey: 'anon' };
const session = (extra = {}) => ({ access_token: 'AT', refresh_token: 'RT', expires_in: 3600, user: { id: 'u1', email: 'a@b.co' }, ...extra });

test('not configured: clear message, no network', async () => {
  const f = fakeFetch([]);
  const c = createClient({ url: '', anonKey: '', fetchImpl: f, storage: memStorage() });
  assert.equal(c.configured(), false);
  await assert.rejects(c.signIn('a@b.co', 'pw'), /not connected to a database/);
  assert.equal(f.calls.length, 0);
});
test('sign in stores session; sign out clears it', async () => {
  const f = fakeFetch([[(u) => u.includes('grant_type=password'), () => resp(200, session())], [(u) => u.endsWith('/logout'), () => resp(204, {})]]);
  const st = memStorage();
  const c = createClient({ ...cfg, fetchImpl: f, storage: st });
  await c.signIn('a@b.co', 'password123');
  assert.equal(c.user.email, 'a@b.co');
  assert.ok(st.getItem('rec.session.v1'));
  await c.signOut();
  assert.equal(c.session, null); assert.equal(st.getItem('rec.session.v1'), null);
});
test('friendly auth errors', async () => {
  const mk = (status, body) => createClient({ ...cfg, storage: memStorage(), fetchImpl: fakeFetch([[() => true, () => resp(status, body)]]) });
  await assert.rejects(mk(400, { error_code: 'invalid_credentials' }).signIn('a@b.co', 'x'), /Incorrect email or password/);
  await assert.rejects(mk(400, { error_code: 'email_not_confirmed' }).signIn('a@b.co', 'x'), /confirm your email/);
  await assert.rejects(mk(429, {}).signIn('a@b.co', 'x'), /Too many attempts/);
  await assert.rejects(mk(422, { error_code: 'weak_password' }).signUp('a@b.co', 'x'), /too weak/);
  const down = createClient({ ...cfg, storage: memStorage(), fetchImpl: async () => { throw new Error('offline'); } });
  await assert.rejects(down.signIn('a@b.co', 'x'), /internet connection/);
});
test('sign up needing email confirmation does not pretend to sign in', async () => {
  const c = createClient({ ...cfg, storage: memStorage(), fetchImpl: fakeFetch([[() => true, () => resp(200, { id: 'u', email: 'a@b.co' })]]) });
  assert.deepEqual(await c.signUp('a@b.co', 'longpassword1'), { signedIn: false, needsConfirmation: true });
  assert.equal(c.session, null);
});
test('expired token is refreshed; invalid refresh signs out', async () => {
  let now = 0;
  const f = fakeFetch([[(u) => u.includes('grant_type=refresh_token'), () => resp(200, session({ access_token: 'AT2' }))]]);
  const st = memStorage();
  st.setItem('rec.session.v1', JSON.stringify({ access_token: 'AT', refresh_token: 'RT', expires_at: 1000, user: { id: 'u1' } }));
  const c = createClient({ ...cfg, fetchImpl: f, storage: st, now: () => now });
  now = 990; assert.equal(await c.getAccessToken(), 'AT2');
  const bad = createClient({ ...cfg, storage: st, now: () => 10_000_000, fetchImpl: fakeFetch([[() => true, () => resp(400, { error: 'invalid' })]]) });
  assert.equal(await bad.getAccessToken(), null); assert.equal(bad.session, null);
});
test('password recovery request and token-based reset', async () => {
  const f = fakeFetch([[(u) => u.includes('/recover'), () => resp(200, {})], [(u) => u.endsWith('/user'), () => resp(200, { id: 'u1' })]]);
  const c = createClient({ ...cfg, fetchImpl: f, storage: memStorage() });
  await c.requestPasswordReset('a@b.co', 'https://site.test/');
  assert.match(f.calls[0].url, /redirect_to=https%3A%2F%2Fsite.test%2F/);
  await c.updatePasswordWithToken('RECOVERY', 'newlongpassword');
  assert.equal(f.calls[1].init.method, 'PUT');
  assert.equal(f.calls[1].init.headers.authorization, 'Bearer RECOVERY');
});
test('recovery link parsing', () => {
  assert.deepEqual(parseRecoveryHash('#access_token=abc&type=recovery&expires_in=3600'), { token: 'abc' });
  assert.equal(parseRecoveryHash('#/dashboard'), null);
  assert.equal(parseRecoveryHash('#access_token=abc&type=signup'), null);
});
test('database client: only known tables, user token + public key sent, db errors explained', async () => {
  const f = fakeFetch([[(u) => u.includes('/rest/v1/tasks'), () => resp(200, [{ id: 1 }])], [(u) => u.includes('/rest/v1/notes'), () => resp(404, { code: 'PGRST205' })]]);
  const st = memStorage(); st.setItem('rec.session.v1', JSON.stringify({ access_token: 'AT', refresh_token: 'RT', expires_at: Date.now() + 3_600_000, user: { id: 'u1' } }));
  const c = createClient({ ...cfg, fetchImpl: f, storage: st });
  assert.deepEqual(await c.select('tasks', 'select=*'), [{ id: 1 }]);
  assert.equal(f.calls[0].init.headers.authorization, 'Bearer AT');
  assert.equal(f.calls[0].init.headers.apikey, 'anon');
  assert.throws(() => c.select('google_tokens'), /Unknown table/);
  await assert.rejects(c.select('notes'), /tables are missing/);
});
test('401 from database after failed refresh ends the session', async () => {
  const st = memStorage(); st.setItem('rec.session.v1', JSON.stringify({ access_token: 'AT', refresh_token: 'RT', expires_at: Date.now() + 3_600_000, user: { id: 'u1' } }));
  const f = fakeFetch([[(u) => u.includes('/rest/'), () => resp(401, {})], [(u) => u.includes('/auth/'), () => resp(400, {})]]);
  const c = createClient({ ...cfg, fetchImpl: f, storage: st });
  await assert.rejects(c.select('tasks'), /sign in again|expired/i);
  assert.equal(c.session, null);
});
test('callApi: attaches token, handles offline, non-JSON and signed-out states', async () => {
  const client = { getAccessToken: async () => 'AT' };
  const ok = await callApi('/api/ai', { json: { a: 1 }, client, fetchImpl: async (u, i) => { assert.equal(i.headers.authorization, 'Bearer AT'); return resp(200, { text: 'hi' }); } });
  assert.equal(ok.ok, true);
  assert.equal((await callApi('/api/ai', { json: {}, client, fetchImpl: async () => { throw new Error('x'); } })).data.error, 'network');
  assert.match((await callApi('/api/ai', { json: {}, client, fetchImpl: async () => new Response('<html>', { status: 404 }) })).data.message, /Netlify/);
  assert.equal((await callApi('/api/ai', { json: {}, client: { getAccessToken: async () => null } })).status, 401);
});
