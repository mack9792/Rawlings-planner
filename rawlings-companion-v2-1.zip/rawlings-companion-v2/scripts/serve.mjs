// Tiny local preview of dist/ (static only; /api functions need Netlify: `npx netlify dev`).
import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const dist = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'dist');
// Apply the SAME Content-Security-Policy Netlify will send, so local runs catch violations.
const csp = (readFileSync(path.join(dist, '..', 'netlify.toml'), 'utf8').match(/Content-Security-Policy = "([^"]*)"/) || [])[1];
const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json' };
http.createServer(async (req, res) => {
  const p = path.normalize(decodeURIComponent(new URL(req.url, 'http://x').pathname)).replace(/^(\.\.[/\\])+/, '');
  try { const f = path.join(dist, p === '/' ? 'index.html' : p); if (!f.startsWith(dist)) throw 0; res.writeHead(200, { 'content-type': types[path.extname(f)] || 'application/octet-stream', ...(csp ? { 'content-security-policy': csp } : {}) }); res.end(await readFile(f)); }
  catch { res.writeHead(404); res.end('Not found'); }
}).listen(process.env.PORT || 4173, () => console.log('Preview on http://localhost:' + (process.env.PORT || 4173)));
