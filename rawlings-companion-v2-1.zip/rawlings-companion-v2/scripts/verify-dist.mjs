// Checks the built site: required files exist, every JS import resolves, and no secret names/values leaked.
import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const SECRET_NAMES = ['SUPABASE_SERVICE_ROLE_KEY', 'ANTHROPIC_API_KEY', 'GROQ_API_KEY', 'GOOGLE_CLIENT_SECRET', 'TOKEN_ENC_KEY'];
const walk = (d) => readdirSync(d).flatMap((f) => { const p = path.join(d, f); return statSync(p).isDirectory() ? walk(p) : [p]; });

export function verifyDist(dist, env = process.env) {
  const problems = [];
  for (const f of ['index.html', 'styles.css', 'note.json', 'src/main.js', 'src/config.js']) if (!existsSync(path.join(dist, f))) problems.push(`missing ${f}`);
  if (problems.length) return problems;
  for (const file of walk(dist)) {
    const text = readFileSync(file, 'utf8');
    for (const n of SECRET_NAMES) { if (text.includes(n)) problems.push(`${path.relative(dist, file)} mentions ${n}`); if (env[n] && env[n].length > 8 && text.includes(env[n])) problems.push(`${path.relative(dist, file)} contains the value of ${n}`); }
    if (file.endsWith('.js')) {
      for (const m of text.matchAll(/(?:from|import)\s*['"](\.[^'"]+)['"]/g)) { if (!existsSync(path.resolve(path.dirname(file), m[1]))) problems.push(`${path.relative(dist, file)} imports missing ${m[1]}`); }
    }
    if (file.endsWith('.html') && /<script(?![^>]*src=)[^>]*>/i.test(text)) problems.push(`${path.relative(dist, file)} has an inline script (blocked by CSP)`);
  }
  return problems;
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const dist = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'dist');
  const p = verifyDist(dist);
  if (p.length) { console.error('VERIFY FAILED:\n- ' + p.join('\n- ')); process.exit(1); }
  console.log('dist verified: files present, imports resolve, no secrets leaked.');
}
