// Zero-dependency production build: copies the static app into dist/ and writes
// the two PUBLIC settings plus the personal note. Refuses to run if a secret key
// is pasted into the public slot.
import { cpSync, rmSync, mkdirSync, writeFileSync, readFileSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

export function looksSecret(key) {
  if (!key) return false;
  if (/^sb_secret_/.test(key)) return true;
  const parts = key.split('.');
  if (parts.length === 3) {
    try { return JSON.parse(Buffer.from(parts[1], 'base64url').toString()).role === 'service_role'; } catch { return false; }
  }
  return false;
}

export function build({ env = process.env, out = path.join(root, 'dist'), log = console.log } = {}) {
  const url = (env.SUPABASE_URL || '').trim().replace(/\/$/, '');
  const anon = (env.SUPABASE_ANON_KEY || '').trim();
  if (looksSecret(anon)) throw new Error('SUPABASE_ANON_KEY contains a SECRET (service_role) key. Use the public "anon"/publishable key there. Build stopped.');
  if (url && !/^https:\/\/[a-z0-9-]+\.supabase\.(co|in)$/i.test(url)) throw new Error('SUPABASE_URL should look like https://xxxx.supabase.co');
  rmSync(out, { recursive: true, force: true });
  mkdirSync(out, { recursive: true });
  cpSync(path.join(root, 'public'), out, { recursive: true });
  cpSync(path.join(root, 'src'), path.join(out, 'src'), { recursive: true });
  writeFileSync(path.join(out, 'src', 'config.js'), `export const CONFIG = ${JSON.stringify({ SUPABASE_URL: url, SUPABASE_ANON_KEY: anon })};\n`);
  const noteFile = path.join(root, 'content', 'bibish-note.txt');
  writeFileSync(path.join(out, 'note.json'), JSON.stringify({ text: existsSync(noteFile) ? readFileSync(noteFile, 'utf8') : '' }));
  if (!url || !anon) log('WARNING: SUPABASE_URL / SUPABASE_ANON_KEY not set. The build works but sign-in will be disabled until they are set.');
  if (/@@PLACEHOLDER@@/.test(readFileSync(path.join(out, 'note.json'), 'utf8'))) log('WARNING: content/bibish-note.txt still holds the placeholder. The personal note page will say it has not been added.');
  log(`Build complete -> ${out}`);
  return out;
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  try { build(); } catch (e) { console.error(`BUILD FAILED: ${e.message}`); process.exit(1); }
}
